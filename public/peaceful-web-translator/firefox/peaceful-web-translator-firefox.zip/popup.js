document.addEventListener('DOMContentLoaded', () => {
  const toggleBtn = document.getElementById('toggleBtn');
  const toggleText = document.getElementById('toggleText');
  const statusIcon = document.getElementById('statusIcon');
  const statusDesc = document.getElementById('statusDesc');
  const openOptions = document.getElementById('openOptions');

  let isEnabled = true;

  const SVG_ACTIVE = '<svg class="icon-spin" width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" stroke="rgba(52, 211, 153, 0.25)" stroke-width="3"></circle><path d="M12 3a9 9 0 0 1 9 9" stroke="#34d399" stroke-width="3" stroke-linecap="round"></path></svg>';
  const SVG_DISABLED = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" fill="#ef4444" stroke="#dc2626" stroke-width="1.5"></circle><path d="M15 9l-6 6M9 9l6 6" stroke="#ffffff" stroke-width="2.5" stroke-linecap="round"></path></svg>';

  function updateUI() {
    if (isEnabled) {
      statusIcon.innerHTML = SVG_ACTIVE;
      toggleBtn.className = 'btn-toggle';
      toggleText.textContent = '変換を一時停止';
      statusDesc.textContent = '変換エンジン稼働中。悪口・嫌味テキストを自動で平和表現へ即座に置換します。';
    } else {
      statusIcon.innerHTML = SVG_DISABLED;
      toggleBtn.className = 'btn-toggle disabled';
      toggleText.textContent = '変換を再開する';
      statusDesc.textContent = '現在一時停止中です。Webサイトのテキストは置換されません。';
    }
  }

  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get({ isEnabled: true }, (res) => {
      isEnabled = res.isEnabled !== false;
      updateUI();
    });
  } else {
    const saved = localStorage.getItem('__peaceful_web_enabled__');
    isEnabled = saved !== 'false';
    updateUI();
  }

  toggleBtn.addEventListener('click', () => {
    isEnabled = !isEnabled;
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.set({ isEnabled }, () => {
        updateUI();
      });
    } else {
      localStorage.setItem('__peaceful_web_enabled__', isEnabled ? 'true' : 'false');
      updateUI();
    }
  });

  openOptions.addEventListener('click', () => {
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.openOptionsPage) {
      chrome.runtime.openOptionsPage();
    } else if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL) {
      window.open(chrome.runtime.getURL('options.html'));
    } else {
      window.open('options.html');
    }
  });
});
