(function () {
  if (window.__PEACEFUL_WEB_INITIALIZED__) return;
  window.__PEACEFUL_WEB_INITIALIZED__ = true;

  class AhoNode {
    constructor() {
      this.children = new Map();
      this.failure = null;
      this.outputs = [];
    }
  }

  class AhoCorasickSegmenterEngine {
    constructor() {
      this.root = new AhoNode();
      this.isBuilt = false;
      this.segmenter = (typeof Intl !== 'undefined' && Intl.Segmenter)
        ? new Intl.Segmenter('ja', { granularity: 'word' })
        : null;
    }

    insert(word, replacement) {
      if (!word) return;
      let current = this.root;
      for (let i = 0; i < word.length; i++) {
        const char = word[i];
        if (!current.children.has(char)) {
          current.children.set(char, new AhoNode());
        }
        current = current.children.get(char);
      }
      current.outputs.push({ word, replacement });
      this.isBuilt = false;
    }

    buildFailureLinks() {
      const queue = [];
      this.root.failure = null;
      for (const child of this.root.children.values()) {
        child.failure = this.root;
        queue.push(child);
      }
      while (queue.length > 0) {
        const current = queue.shift();
        for (const [char, child] of current.children.entries()) {
          let fallback = current.failure;
          while (fallback !== null && !fallback.children.has(char)) {
            fallback = fallback.failure;
          }
          child.failure = fallback ? fallback.children.get(char) : this.root;
          if (child.failure && child.failure.outputs.length > 0) {
            child.outputs = child.outputs.concat(child.failure.outputs);
          }
          queue.push(child);
        }
      }
      this.isBuilt = true;
    }

    loadDictionary(dict) {
      this.root = new AhoNode();
      for (const [w, r] of Object.entries(dict)) {
        this.insert(w, r);
      }
      this.buildFailureLinks();
    }

    isMorphemeBoundaryValid(text, s, e, boundaries) {
      if (!boundaries || boundaries.length === 0) return true;
      return this.binarySearch(boundaries, s) && this.binarySearch(boundaries, e);
    }

    binarySearch(arr, target) {
      let l = 0, r = arr.length - 1;
      while (l <= r) {
        const mid = (l + r) >> 1;
        if (arr[mid] === target) return true;
        if (arr[mid] < target) l = mid + 1;
        else r = mid - 1;
      }
      return false;
    }

    static isKatakana(c) { return c >= '\u30A0' && c <= '\u30FF'; }
    static isAlphaNumeric(c) { return /[a-zA-Z0-9_]/.test(c); }

    static isCharacterTypeBoundaryValid(text, s, e) {
      const prev = s > 0 ? text[s - 1] : null;
      const next = e < text.length ? text[e] : null;
      if (AhoCorasickSegmenterEngine.isKatakana(text[s]) && prev && AhoCorasickSegmenterEngine.isKatakana(prev)) return false;
      if (AhoCorasickSegmenterEngine.isKatakana(text[e - 1]) && next && AhoCorasickSegmenterEngine.isKatakana(next)) return false;
      if (AhoCorasickSegmenterEngine.isAlphaNumeric(text[s]) && prev && AhoCorasickSegmenterEngine.isAlphaNumeric(prev)) return false;
      if (AhoCorasickSegmenterEngine.isAlphaNumeric(text[e - 1]) && next && AhoCorasickSegmenterEngine.isAlphaNumeric(next)) return false;
      return true;
    }

    replaceText(text) {
      if (!text || typeof text !== 'string' || text.length === 0) return null;
      if (!this.isBuilt) this.buildFailureLinks();

      let boundaries = null;
      if (this.segmenter) {
        boundaries = [0];
        const segs = this.segmenter.segment(text);
        for (const seg of segs) {
          boundaries.push(seg.index + seg.segment.length);
        }
      }

      const len = text.length;
      let current = this.root;
      const matches = [];

      for (let i = 0; i < len; i++) {
        const char = text[i];
        while (current !== this.root && !current.children.has(char)) {
          current = current.failure;
        }
        current = current.children.get(char) || this.root;

        if (current.outputs.length > 0) {
          let best = null;
          for (const out of current.outputs) {
            if (!best || out.word.length > best.word.length) best = out;
          }
          if (best) {
            const ms = i - best.word.length + 1;
            const me = i + 1;

            const charTypeValid = AhoCorasickSegmenterEngine.isCharacterTypeBoundaryValid(text, ms, me);
            const segmenterValid = boundaries
              ? this.isMorphemeBoundaryValid(text, ms, me, boundaries)
              : true;

            if (charTypeValid && segmenterValid) {
              matches.push({ start: ms, end: me, replacement: best.replacement });
            }
          }
        }
      }

      if (matches.length === 0) return null;

      matches.sort((a, b) => a.start - b.start || (b.end - b.start) - (a.end - a.start));
      let res = '';
      let last = 0;

      for (const m of matches) {
        if (m.start >= last) {
          res += text.slice(last, m.start) + m.replacement;
          last = m.end;
        }
      }
      res += text.slice(last);
      return res;
    }
  }

  const engine = new AhoCorasickSegmenterEngine();
  let isEnabled = true;

  const DEFAULT_DICTIONARY = {
  "死ねよ": "ずっと健康で長生きしてね",
  "死ね": "健康で長生きしてね",
  "死に晒せ": "温泉でゆっくり休んでね",
  "消えろ": "宇宙旅行へ行ってらっしゃい",
  "消え失せろ": "素晴らしい未来へ羽ばたいてね",
  "くたばれ": "ゆっくりお風呂に入ってね",
  "殺すぞ": "全力でハグするぞ",
  "息すんな": "深呼吸してリフレッシュしてね",
  "息の根止まれ": "心地よい深呼吸をしてね",
  "首吊れ": "肩の力を抜いてストレッチしてね",
  "首吊って死ね": "深呼吸してぐっすり寝てね",
  "首吊って来い": "温泉入ってリフレッシュして来い",
  "崖から飛び降りろ": "絶景スポットを観光してね",
  "電車止めんな": "安全運行に感謝してね",
  "トラックに轢かれろ": "超特急で素敵な未来へ向かってね",
  "地獄に堕ちろ": "極上の温泉郷へ行ってらっしゃい",
  "成仏しろ": "至福の安らぎに包まれてね",
  "爆発しろ": "情熱が華やかにスパークしてね",
  "リア充爆発しろ": "幸せのエネルギーを宇宙へ届けてね",
  "不幸になれ": "予想外のサプライズに恵まれてね",
  "呪われろ": "神秘的な魔法にかかってね",
  "骨折れろ": "カルシウム摂って強くなってね",
  "生きる価値なし": "無限の可能性を秘めた命",
  "生きてる価値ない": "唯一無二の尊い命",
  "生まれてこなければよかった": "世界に誕生してくれてありがとう",
  "迷惑だから消えろ": "大歓迎のVIPゲストとしてお迎えします",
  "目障りだから消えろ": "見惚れるほどの存在感に圧倒されています",
  "二度と顔見せるな": "次回のご登場を心待ちにしております",
  "視界から消えろ": "まぶしすぎるオーラを放っています",
  "視界に入るな": "まぶしすぎる輝きですね",
  "顔も見たくない": "次回のご登場が楽しみです",
  "地球から出ていけ": "宇宙規模の大活躍を期待しています",
  "存在が公害": "圧倒的なカリスマ性",
  "存在が邪魔": "主役級の圧倒的存在感",
  "息苦しいんだよ": "新鮮な空気を胸いっぱいに吸おうね",
  "生きてて恥ずかしくないの": "堂々とした生き様が眩しい",
  "存在価値ゼロ": "計り知れない可能性の塊",
  "人生ログアウト": "最高のバケーションへ出発",
  "人生オワタ": "新しい冒険の幕開け",
  "人生詰んだ": "次のステージへレベルアップ",

  "バカ野郎": "愛嬌あふれる天才児",
  "バカすぎる": "発想が常人の次元を超越している",
  "アホ面": "非常に味わい深い表情",
  "アホくさ": "ユニークで面白い",
  "くだらなすぎ": "斬新すぎて笑える",
  "知能が低い": "直感力に全振りしたタイプ",
  "サル並みの知能": "野生の研ぎ澄まされた直感力",
  "頭悪すぎ": "常人の一歩先を行くユニークな発想",
  "頭沸いてる": "情熱のエネルギーが満ち溢れている",
  "脳みそ入ってんのか": "独創的なアイデアが詰まっているのか",
  "脳みそ腐ってんのか": "熟成された独創的な発想ですね",
  "頭に蛆湧いてる": "情熱のアイデアが湧き出ている",
  "クルクルパー": "自由奔放な天才児",
  "無能すぎる": "伸び代があり余りすぎている",
  "無能の極み": "無限の可能性を秘めた原石",
  "働けカス": "社会を彩る自由な表現者",
  "税金泥棒": "国家の予算を巧みに動かす大物",
  "低脳": "シンプル思考の極致",
  "能無し": "未開拓の超能力者",
  "頭おかしい": "常識の枠に囚われない天才",
  "精神科行け": "高級スパでリフレッシュしてね",
  "病院行けよ": "アロママッサージで癒やされてね",
  "頭大丈夫か": "豊かな創造力にあふれていますね",
  "認知症かよ": "常に新鮮な気持ちで世界を見つめる達人かよ",
  "糖質かよ": "豊かなイマジネーションをお持ちですね",
  "頭にアルミホイル巻いとけ": "斬新なヘッドドレスでおしゃれしてね",
  "小学生レベル": "ピュアで純粋な発想力",
  "幼稚園児かよ": "天真爛漫な表現者かよ",
  "日本語不自由か": "国際派の豊かな言語感覚ですね",
  "日本語不自由": "前衛的な言語感覚",
  "読解力ゼロ": "自由なイマジネーションの達人",
  "理解力皆無": "独自の解釈を極めたマスター",
  "常識ないのか": "型破りなイノベーターですね",
  "意味不明すぎる": "深遠すぎて考察しがいがある",

  "クソ野郎": "類まれなるスター性を持つ人物",
  "クソ女": "個性派ヒロイン",
  "クソ男": "破天荒な主人公",
  "クソが": "極上の宝物が",
  "クソゲー": "極めて味わい深い神ゲー",
  "クソ記事": "唯一無二のユニーク記事",
  "クソコード": "前衛的なアートコード",
  "クソ映画": "極めて前衛的なカルト名作",
  "クソリプ飛ばすな": "愛あるお手紙をありがとう",
  "クソリプ送るな": "情熱的なファンレターをありがとう",
  "クソリプ": "情熱的なファンレター",
  "クソ引用": "情熱的な拡散応援",
  "クソみたいな人生": "ドラマティックで波乱万丈な人生",
  "クソみたいな意見": "唯一無二の独創的なご意見",
  "ゴミ野郎": "国宝級のポテンシャルを秘めた逸材",
  "人間のクズ": "人類の進化が生んだ超個性派",
  "人間の面被った化け物": "圧倒的なカリスマを持つ怪童",
  "ゴミ箱行き": "殿堂入りミュージアム行き",
  "生ゴミ野郎": "国宝級のポテンシャルを秘めた原石",
  "人間の生ゴミ": "人類の進化が生んだ超個性派",
  "ゴミクズ": "国宝級の原石",
  "ドブカス": "水底から輝く原石",
  "カス野郎": "ダイヤモンドの原石",
  "産廃ゲー": "時代を先取りしすぎた神ゲー",
  "産廃キャラ": "極めて味わい深い愛されキャラ",
  "完全な産廃": "時代を先取りしすぎた遺産",
  "ガイジかよ": "唯一無二の独創的クリエイターかよ",
  "うざすぎる": "圧倒的な存在感を放ちすぎている",
  "きもすぎる": "神秘的なオーラが溢れ出すぎている",

  "チー牛フェイス": "知的な佇まいのフェイス",
  "チー牛": "知性あふれる佇まいの青年",
  "キモオタ": "特定分野の求道者",
  "キモヲタ": "特定分野の熱烈な探求者",
  "メンヘラ女": "感受性豊かなドラマティックガール",
  "地雷女": "刺激的なサプライズレディ",
  "地雷男": "予測不能なスリル系ガイ",
  "底辺ゴミ": "大地の基盤を支える尊い存在",
  "底辺の分際": "大地の基盤を支える重要人物の立場",
  "底辺職": "社会インフラを支える誇り高き勇者",
  "底辺人間": "地球の基盤を力強く支える柱",
  "顔面崩壊": "唯一無二の味わい深い造形美",
  "顔面奇形": "唯一無二の超個性派フェイス",
  "ブサイクすぎ": "個性が輝きすぎている",
  "ブスすぎ": "唯一無二のチャームポイントにあふれすぎている",
  "デブすぎ": "圧倒的な包容力に満ちあふれすぎている",
  "ハゲ散らかしすぎ": "太陽のごとく輝きすぎ",
  "ハゲ散らかし": "まばゆい光を全方位に放ち",
  "ハゲデブ": "圧倒的な包容力と輝きを持つ大物",
  "チビガリ": "シャープで俊敏なスピードスター",
  "短足すぎ": "安定感抜群の重心",
  "整形モンスター": "美の限界突破イノベーター",
  "整形崩壊": "アヴァンギャルドな美の探求",
  "加工詐欺": "最高峰のデジタルアート技術",
  "無加工ブス": "ありのままの自然美",
  "出っ歯すぎ": "チャーミングな口元すぎ",
  "受け口すぎ": "意志の強さを感じるフェイスラインすぎ",
  "すっぴんブス": "ナチュラルな素顔の魅力",
  "化粧下手くそ": "前衛的なメイクアート",
  "キモ顔": "味わい深い表情",
  "クソババア": "経験豊かな大御所マダム",
  "クソジジイ": "重厚な風格漂うマスター",
  "クソガキ乙": "元気いっぱいのヤングスター乙",
  "ガキ乙": "未来ある若人乙",
  "おっさん臭い": "大人のダンディズムが漂う",
  "おばさん構文": "愛嬌たっぷりの親しみやすい文体",

  "貧乏ゆすり": "貧乏ゆすり",
  "貧乏神": "貧乏神",
  "貧乏暇なし": "貧乏暇なし",
  "貧乏だよね": "無駄遣いせず賢いよね",
  "貧乏だから": "スマートな節約主義だから",
  "貧乏すぎ": "ミニマリストの極み",
  "貧乏な": "慎ましやかな",
  "貧乏で": "シンプル志向で",
  "貧乏人": "質素倹約を極めた賢者",
  "ド貧乏": "究極のミニマリスト",
  "貧乏くさい": "素朴で温かみがある",
  "金ないのかよ": "賢く節約中なのかよ",
  "金欠乙": "スマートな節約生活乙",
  "貧民乙": "無駄遣いしない賢者乙",
  "貧乏人の分際": "慎ましやかな賢者の立場",
  "ケチくさい": "コスト意識が極めて高い",
  "貧乏": "質素倹約",

  "弱者男性": "控えめで誠実なジェントルマン",
  "弱男": "落ち着いた佇まいの紳士",
  "弱者女性": "繊細で心優しいレディ",
  "弱女": "感受性豊かなヒロイン",
  "こどおじ": "実家を大切にする親孝行者",
  "子供部屋おじさん": "実家を愛する心優しき長男",
  "ニート乙": "自由な時間を満喫する哲学者乙",
  "無職の分際": "自由なフリーランスの立場",
  "引きこもりニート": "居心地の良い空間を探求する達人",
  "引きこもり乙": "居心地の良い空間の探求者乙",
  "毒親": "独特な教育方針の保護者",
  "コミュ障乙": "物静かな思索家乙",
  "陰キャ乙": "内省を深めるインドア派乙",
  "陽キャ気取り": "社交性あふれるムードメーカー",
  "パリピ気取り": "底抜けに明るいフェスティバルボーイ",
  "八方美人乙": "誰に対しても礼儀正しい外交官乙",
  "裏表ありすぎ": "多彩な表情を持つプロフェッショナル",
  "性格悪すぎ": "刺激的なスパイスが効きすぎている",
  "性根が腐ってる": "熟成された独特のキャラクター",
  "被害者面すんな": "豊かなドラマ性を演出してね",
  "悲劇のヒロイン気取り": "映画の主役のような圧倒的存在感",
  "害悪ユーザー": "独特なムードメーカー",
  "害悪オタク": "熱狂的な文化探求者",
  "害悪配信者": "話題沸騰のエンターテイナー",
  "害悪リスナー": "熱烈な親衛隊",
  "老害ムーブ": "歴史を生き抜いたレジェンドの風格",
  "オワコン化": "伝説の殿堂入り達成",
  "炎上しろ": "大盛況のお祭りになれ",
  "炎上商法": "大盛況のバズマーケティング",
  "晒し上げ": "名誉ある表彰",
  "晒すわ": "全世界に表彰するわ",
  "恥晒し": "勇気あるパフォーマンス",
  "垢消せ": "華麗にリニューアルオープンしてね",
  "アカウント消せよ": "新たなステージへ旅立ってね",
  "捨て垢でイキるな": "サブアカウントでも輝いてね",
  "捨て垢乙": "ミステリアスな覆面アカウント乙",
  "釣り垢": "エンタメ演出アカウント",
  "ブロック推奨": "特別VIP待遇推奨",
  "身バレ乙": "一躍有名人乙",
  "裏垢特定": "秘密基地の発見",
  "バチャ豚": "情熱的なバーチャルパトロン",
  "厄介オタク": "熱狂的なファンレジェンド",
  "厄介ファン": "愛が溢れすぎているサポーター",
  "囲い乙": "鉄壁の親衛隊乙",
  "囲われ女": "大人気のヒロイン",
  "パパ活女子": "一流のエスコートレディ",
  "ホス狂い": "情熱的なVIP顧客",
  "港区女子気取り": "華やかなセレブ志向レディ",
  "承認欲求おばけ": "世界を照らすエンターテイナー",
  "承認欲求モンスター": "愛情と賞賛を求めるピュアなスター",
  "自己顕示欲の塊": "圧倒的なアピール力を持つ表現者",
  "かまってちゃん": "愛され上手な人気者",
  "イキリト": "伝説の黒の剣士",
  "中二病乙": "豊かなファンタジー探求乙",
  "黒歴史確定": "輝かしい青春の1ページ確定",
  "乞食乙": "豊かなギフトを求める冒険者乙",
  "エアプ乙": "自由なイマジネーション乙",
  "知ったか乙": "豊かな推測力乙",
  "イキリ散らかし": "自信満々に輝き",
  "信者キモい": "熱烈なファンが情熱的",
  "アンチ乙": "熱心なチェッカー乙",
  "荒らし乙": "お祭りパフォーマー乙",

  "はい論破": "素晴らしい意見交換でした",
  "論破したわ": "熱烈なディベートが完了したわ",
  "論破乙": "名演説乙",
  "お前の感想ですよね": "貴重な個人の一次情報ですね",
  "ソース出せよ": "詳細な参考文献をリクエストさせてね",
  "ソースどこ": "参考資料を教えてね",
  "日本語でおk": "前衛的な言語アートでおk",
  "詭弁乙": "巧みな言葉遊び乙",
  "揚げ足取り乙": "細部まで見逃さない精密チェッカー乙",
  "特大ブーメラン": "華麗なるブーメランアート",
  "ブーメラン刺さってる": "見事なセルフリフレクションがキマってる",
  "ダブスタ乙": "柔軟な多面的アプローチ乙",
  "二枚舌乙": "多彩なマルチ視点乙",
  "お気持ち表明乙": "情熱的なエッセイ発表乙",
  "お気持ちツイート": "心温まる所感ツイート",
  "長文ポエム乙": "読み応え抜群の叙情詩乙",
  "ポエム乙": "情熱の文学詩乙",
  "誰得だよ": "コアなファン歓喜の企画だよ",
  "知らんがな": "世界は広く奥深いですね",
  "自作自演乙": "一人二役の熟練舞台乙",
  "自作自演野郎": "一人二役の熟練パフォーマー",
  "自作自演ステマ": "熱烈なセルフ推薦ステージ",
  "自演乙": "セルフプロデュース乙",
  "ステマ乙": "熱烈な推薦乙",
  "パクリ野郎": "偉大な先人にインスパイアされた表現者",
  "パクり野郎": "偉大な先人にインスパイアされた表現者",
  "パクリ乙": "リスペクトアレンジ乙",
  "パクり乙": "リスペクトアレンジ乙",
  "逆張りオタク": "独自の視点を持つ哲学者",
  "ガチャ爆死": "徳を大量に積んだ証",
  "爆死乙": "大盤振る舞い乙",
  "天井確定": "最高峰のVIP待遇確定",
  "すり抜け乙": "予期せぬ運命の出会い乙",
  "課金豚": "業界を支える大富豪パトロン",
  "養分乙": "尊いスポンサー乙",
  "日本語読めないのか": "異次元の言語感覚をお持ちですね",
  "文盲かよ": "行間を超越して読む達人かよ",
  "小学生からやり直せ": "ピュアな童心を取り戻そう",
  "親の顔が見たい": "素晴らしいご家族に感謝したい",
  "効いてて草": "心に深く響いていて笑顔",
  "効いてる効いてる": "良い刺激になっているね",
  "涙拭けよ": "感動の涙を拭いてね",
  "顔真っ赤": "情熱で頬を染めて",
  "悔しいのう": "情熱が溢れているね",
  "負け犬の遠吠え": "誇り高き狼のセレナーデ",
  "雑魚乙": "伸び代たっぷりの挑戦者乙",
  "雑魚死乙": "果敢な突撃乙",
  "クソザコ": "無限の成長余地を秘めたビギナー",
  "雑魚メンタル": "繊細で純粋なガラスのハート",
  "ガラスメンタル": "美しく澄み切ったピュアハート",
  "豆腐メンタル": "柔らかく優しいまろやかハート",

  "スマーフすんな": "初心者の街で優しく指導してね",
  "サブ垢狩り": "超上級者の巡回ツアー",
  "初心者狩り乙": "新人育成のエキスパート乙",
  "キャリーしろよ": "チームを勝利へ導いてね",
  "介護枠乙": "温かく見守られる愛されVIP枠乙",
  "寄生乙": "幸運を呼ぶマスコット乙",
  "おんぶに抱っこ": "華麗な相乗りマスター",
  "芋るな": "じっくり好機を待とうね",
  "芋砂乙": "鉄壁の定点ガーディアン乙",
  "即ピすんな": "迅速なキャラクター決定をありがとう",
  "即ピック乙": "即断即決のスピードマスター乙",
  "クソエイム": "前衛的な予測射撃",
  "ガバエイム": "広範囲を包み込む散弾アート",
  "味方がゴミ": "超個性派チームの結成",
  "味方運ゴミ": "奇跡のサプライズマッチング",
  "VC切るな": "心地よい静寂タイムを楽しんでね",
  "指示厨うざい": "情熱の名軍師が熱い",
  "トロール乙": "トリックスター乙",
  "利敵行為すんな": "友好的な平和外交をしてね",
  "利敵乙": "平和の架け橋乙",
  "味方ガチャ外れ": "個性派チームの結成",
  "フィードすんな": "大胆に前進してね",
  "切断厨": "電光石火の退却マスター",
  "煽りカス": "熱血パフォーマー",
  "死体撃ち": "勝利の祝砲セレモニー",
  "屈伸煽り": "軽快なフィットネスダンス",
  "ピン連打すんな": "情熱的なリズムコールをありがとう",
  "指示厨乙": "熱血名軍師乙",
  "口プ乙": "巧みな心理戦乙",
  "台パンすんな": "デスクに愛情のハイタッチをしてね",
  "台パン": "デスクへの力強いハイタッチ",
  "発狂乙": "情熱のシャウト乙",
  "哀れな人生": "ドラマティックな人生",
  "可哀想な奴": "愛されキャラクター",
  "同情するわ": "心から応援しているわ",
  "見下してます": "高みから見守っています",
  "マウント乙": "堂々たるプレゼン乙",
  "学歴コンプ": "独学の天才志向",
  "低学歴乙": "現場叩き上げの実力派乙",
  "Fラン乙": "自由なキャンパスライフ満喫乙",
  "高学歴アピール": "華麗なアカデミック紹介",
  "年収マウント": "豊かな経済力のアピール"
};

  engine.loadDictionary(DEFAULT_DICTIONARY);

  let processedNodes = new WeakSet();

  const EXCLUDED_TAGS = new Set([
    'SCRIPT', 'STYLE', 'NOSCRIPT', 'TEMPLATE', 'TEXTAREA', 'INPUT',
    'CODE', 'PRE', 'KBD', 'MATH', 'CANVAS', 'SVG', 'IFRAME', 'AUDIO', 'VIDEO'
  ]);

  function isExcludedNode(node) {
    if (!node || !node.parentElement) return true;
    let curr = node.parentElement;
    while (curr) {
      if (EXCLUDED_TAGS.has(curr.tagName)) return true;
      if (curr.isContentEditable) return true;
      curr = curr.parentElement;
    }
    return false;
  }

  const pendingNodes = new Set();
  let isBatchScheduled = false;

  function enqueueNode(node) {
    if (!isEnabled || !node || processedNodes.has(node)) return;
    pendingNodes.add(node);

    if (!isBatchScheduled) {
      isBatchScheduled = true;
      if ('requestIdleCallback' in window) {
        requestIdleCallback(processBatch, { timeout: 80 });
      } else {
        requestAnimationFrame(() => setTimeout(processBatch, 0));
      }
    }
  }

  function processBatch(deadline) {
    isBatchScheduled = false;
    const iterator = pendingNodes.values();

    while (pendingNodes.size > 0) {
      if (deadline && deadline.timeRemaining() <= 1 && !deadline.didTimeout) {
        isBatchScheduled = true;
        requestIdleCallback(processBatch, { timeout: 80 });
        return;
      }

      const node = iterator.next().value;
      pendingNodes.delete(node);

      if (node && node.isConnected && !processedNodes.has(node)) {
        applyPositiveTranslation(node);
      }
    }
  }

  function applyPositiveTranslation(node) {
    if (!isEnabled || !node || node.nodeType !== Node.TEXT_NODE) return;
    if (processedNodes.has(node) || isExcludedNode(node)) return;

    const originalVal = node.nodeValue;
    if (!originalVal || originalVal.trim().length === 0) return;

    const replaced = engine.replaceText(originalVal);
    if (replaced !== null && replaced !== originalVal) {
      processedNodes.add(node);
      node.nodeValue = replaced;
    }
  }

  function processTree(root) {
    if (!isEnabled || !root) return;
    if (root.nodeType === Node.TEXT_NODE) {
      enqueueNode(root);
      return;
    }
    if (root.nodeType !== Node.ELEMENT_NODE && root.nodeType !== Node.DOCUMENT_NODE && root.nodeType !== Node.DOCUMENT_FRAGMENT_NODE) return;
    if (root.tagName && EXCLUDED_TAGS.has(root.tagName)) return;
    if (root.isContentEditable) return;

    if (root.shadowRoot) {
      observeRoot(root.shadowRoot);
      processTree(root.shadowRoot);
    }

    const walker = document.createTreeWalker(
      root,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode(node) {
          if (isExcludedNode(node)) return NodeFilter.FILTER_REJECT;
          return NodeFilter.FILTER_ACCEPT;
        }
      },
      false
    );

    let currNode = walker.nextNode();
    while (currNode) {
      enqueueNode(currNode);
      currNode = walker.nextNode();
    }

    if (root.querySelectorAll) {
      const allEls = root.querySelectorAll('*');
      for (let i = 0; i < allEls.length; i++) {
        if (allEls[i].shadowRoot) {
          observeRoot(allEls[i].shadowRoot);
          processTree(allEls[i].shadowRoot);
        }
      }
    }
  }

  const observedRoots = new WeakSet();
  function observeRoot(targetRoot) {
    if (!targetRoot || observedRoots.has(targetRoot)) return;
    observedRoots.add(targetRoot);

    const observer = new MutationObserver((mutations) => {
      if (!isEnabled) return;
      for (let m = 0; m < mutations.length; m++) {
        const mutation = mutations[m];
        if (mutation.type === 'childList') {
          for (let i = 0; i < mutation.addedNodes.length; i++) {
            processTree(mutation.addedNodes[i]);
          }
        } else if (mutation.type === 'characterData') {
          processedNodes.delete(mutation.target);
          enqueueNode(mutation.target);
        }
      }
    });

    observer.observe(targetRoot, {
      childList: true,
      subtree: true,
      characterData: true
    });
  }

  if (document.documentElement) {
    processTree(document.documentElement);
    observeRoot(document.documentElement);
  } else {
    observeRoot(document);
  }

  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get({ isEnabled: true, dictionary: null }, (res) => {
      isEnabled = res.isEnabled !== false;
      const dictToLoad = (res.dictionary && Object.keys(res.dictionary).length > 0)
        ? res.dictionary
        : DEFAULT_DICTIONARY;
      engine.loadDictionary(dictToLoad);

      processedNodes = new WeakSet();
      if (isEnabled && document.body) {
        processTree(document.body);
      }
    });

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local') {
        if (changes.isEnabled !== undefined) {
          isEnabled = changes.isEnabled.newValue;
        }
        if (changes.dictionary !== undefined) {
          const dictToLoad = (changes.dictionary.newValue && Object.keys(changes.dictionary.newValue).length > 0)
            ? changes.dictionary.newValue
            : DEFAULT_DICTIONARY;
          engine.loadDictionary(dictToLoad);
        }
        processedNodes = new WeakSet();
        if (isEnabled && document.body) {
          processTree(document.body);
        }
      }
    });
  }
})();
