chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    chrome.storage.local.get(['isEnabled'], (res) => {
      if (typeof res.isEnabled === 'undefined') {
        chrome.storage.local.set({ isEnabled: true });
      }
    });
  }
});
