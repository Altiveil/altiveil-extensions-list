(function () {
  if (window.__OUTER_BOX_RULER_INITIALIZED__) {
    if (typeof window.__OUTER_BOX_RULER_TOGGLE__ === 'function') {
      window.__OUTER_BOX_RULER_TOGGLE__();
    }
    return;
  }
  window.__OUTER_BOX_RULER_INITIALIZED__ = true;
  let isActive = false;
  let isInteracting = false;
  let interactMode = null; 
  let resizeHandle = null;
  let startX = 0;
  let startY = 0;
  let initialBox = null;
  let currentBox = null;
  let selectedElement = null; 
  let activeUnit = 'px'; 
  let snapGrid = 'none'; 
  let isPanelMinimized = false;
  let activeTabFormat = 'tailwind';
  const I18N_DICT = {
    ja: {
      panelTitle: '外枠逆算結果',
      waiting: '待機中',
      settings: '拡張機能設定',
      minimize: '最小化',
      close: '閉じる',
      drawerTitle: '拡張機能・ガイド設定',
      realtimeReflection: 'リアルタイム反映',
      dualGuideTitle: '階層別デュアル距離ガイド',
      dualGuideDesc: '親コンテナ＆隣接要素までの二段階測定',
      measureWaiting: '計測待機中',
      dragOrClickDesc: '画面上をドラッグして配置枠を描画するか、要素をクリックしてください。',
      shortcutDesc: 'ショートカット: 矢印キーで1px移動 / Alt+矢印でリサイズ',
      parent: '親',
      adjTop: '隣接-上',
      parentTop: '親-上',
      adjLeft: '隣接-左',
      parentLeft: '親-左',
      adjRight: '隣接-右',
      parentRight: '親-右',
      adjBottom: '隣接-下',
      parentBottom: '親-下',
      unit: '単位',
      snap: 'スナップ',
      snapNone: '無',
      gapReverseTitle: '外側コンテナ Gap逆算 (2カラム間)',
      leftElement: '← 左要素',
      rightElement: '→ 右要素',
      parentInner: '親内枠',
      topMetric: '上 (Top)',
      leftMetric: '左 (Left)',
      rightMetric: '右 (Right)',
      bottomMetric: '下 (Bottom)',
      cbReasonLabel: '形成根拠',
      stdScaleTitle: 'Standard Scale (標準4pxトークン)',
      arbitraryTitle: 'Arbitrary (任意値 [px] 記法)',
      absoluteTitle: '絶対配置 (Absolute: Containing Block基準)',
      fluidTitle: 'フルード clamp() レスポンシブ',
      stdCssTitle: '標準CSS (Margin / Absolute)',
      nudgeTitle: '位置・サイズ微調整',
      btnDock: '↙ ドッキングを戻す',
      btnDetach: '↗ ウィンドウ切り離し',
      detachedNotice: '切り離し小ウィンドウで操作中 ↗',
      detachedSubNotice: '（矢印キー操作もリアルタイム有効）',
      nudgeMove: '位置移動 (1px)',
      nudgeResize: 'サイズ拡縮 (1px)',
      nudgeShortcutHelp: '矢印キー(Shift:10px / Alt:サイズ)',
      btnCopy: 'コピー',
      copied: 'コピー済'
    },
    en: {
      panelTitle: 'Spacing Metrics',
      waiting: 'Ready',
      settings: 'Settings',
      minimize: 'Minimize',
      close: 'Close',
      drawerTitle: 'Guide & Extension Settings',
      realtimeReflection: 'Live Update',
      dualGuideTitle: 'Dual Hierarchy Distance Guide',
      dualGuideDesc: '2-step distance to parent container & adjacent sibling',
      measureWaiting: 'Ready to Measure',
      dragOrClickDesc: 'Drag to draw a bounding box, or click any element on the page.',
      shortcutDesc: 'Shortcuts: Arrow keys for 1px move / Alt+Arrow for resize',
      parent: 'Parent',
      adjTop: 'Adj-Top',
      parentTop: 'P-Top',
      adjLeft: 'Adj-Left',
      parentLeft: 'P-Left',
      adjRight: 'Adj-Right',
      parentRight: 'P-Right',
      adjBottom: 'Adj-Bottom',
      parentBottom: 'P-Bottom',
      unit: 'Unit',
      snap: 'Snap',
      snapNone: 'Off',
      gapReverseTitle: 'Outer Container Gap (2-Column Gap)',
      leftElement: '← Left Element',
      rightElement: '→ Right Element',
      parentInner: 'Parent Box',
      topMetric: 'Top',
      leftMetric: 'Left',
      rightMetric: 'Right',
      bottomMetric: 'Bottom',
      cbReasonLabel: 'Containing Block',
      stdScaleTitle: 'Standard Scale (4px tokens)',
      arbitraryTitle: 'Arbitrary ([px] notation)',
      absoluteTitle: 'Absolute (Containing Block base)',
      fluidTitle: 'Fluid clamp() Responsive',
      stdCssTitle: 'Standard CSS (Margin / Absolute)',
      nudgeTitle: 'Position & Size Nudge',
      btnDock: '↙ Dock Back',
      btnDetach: '↗ Detach Window',
      detachedNotice: 'Controlling via floating window ↗',
      detachedSubNotice: '(Arrow keys work in real-time)',
      nudgeMove: 'Move (1px)',
      nudgeResize: 'Resize (1px)',
      nudgeShortcutHelp: 'Arrow keys (Shift: 10px / Alt: resize)',
      btnCopy: 'Copy',
      copied: 'Copied'
    }
  };

  let currentI18nLang = 'ja';
  function resolveI18nLang(pref) {
    if (pref === 'ja' || pref === 'en') return pref;
    const navLang = (navigator.language || '').toLowerCase();
    return navLang.startsWith('ja') ? 'ja' : 'en';
  }
  function t(key) {
    const dict = I18N_DICT[currentI18nLang] || I18N_DICT.en;
    return dict[key] || key;
  }

 
  function getRootFontSize() {
    try {
      const fs = parseFloat(window.getComputedStyle(document.documentElement).fontSize);
      return (!isNaN(fs) && fs > 0) ? fs : 16;
    } catch (e) {
      return 16;
    }
  }
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get({ defaultUnit: 'px', defaultSnap: 'none', lang: 'auto' }, (items) => {
      currentI18nLang = resolveI18nLang(items.lang);
      if (items.defaultUnit) activeUnit = items.defaultUnit;
      if (items.defaultSnap) snapGrid = items.defaultSnap;
    });
  }
  const host = document.createElement('div');
  host.id = 'outer-box-ruler-root';
  host.style.position = 'fixed';
  host.style.top = '0';
  host.style.left = '0';
  host.style.width = '100vw';
  host.style.height = '100vh';
  host.style.zIndex = '2147483647';
  host.style.pointerEvents = 'none';
  host.style.display = 'none';
  function attachHost() {
    const parent = document.body || document.documentElement;
    if (parent && !document.getElementById('outer-box-ruler-root')) {
      parent.appendChild(host);
    }
  }
  attachHost();
  const shadow = host.attachShadow({ mode: 'open' });
  const style = document.createElement('style');
  style.textContent = `
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      -webkit-font-smoothing: antialiased;
    }
    .overlay {
      position: fixed;
      inset: 0;
      width: 100vw;
      height: 100vh;
      cursor: crosshair;
      pointer-events: auto;
      background: rgba(9, 9, 11, 0.18);
      user-select: none;
    }
    .top-banner {
      position: fixed;
      top: 18px;
      left: 50%;
      transform: translateX(-50%);
      background: rgba(24, 24, 27, 0.96);
      color: #fafafa;
      border: 1px solid #3f3f46;
      padding: 8px 18px;
      border-radius: 12px;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.8);
      backdrop-filter: blur(12px);
      display: flex;
      align-items: center;
      gap: 12px;
      font-size: 12px;
      font-weight: 500;
      pointer-events: auto;
      z-index: 100;
      user-select: none;
    }
    .status-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: #34d399;
      box-shadow: 0 0 6px #34d399;
    }
    .btn-close-top {
      background: #27272a;
      color: #fafafa;
      border: 1px solid #3f3f46;
      padding: 4px 10px;
      border-radius: 6px;
      font-size: 11px;
      font-weight: 700;
      cursor: pointer;
      transition: background 0.15s;
    }
    .btn-close-top:hover { background: #3f3f46; }
    .ruler-svg {
      position: fixed;
      inset: 0;
      width: 100vw;
      height: 100vh;
      pointer-events: none;
      z-index: 10;
    }
    .selected-box {
      position: fixed;
      border: 2px solid #ffffff;
      background: rgba(255, 255, 255, 0.1);
      cursor: move;
      pointer-events: auto;
      z-index: 20;
      box-shadow: 0 0 0 1px rgba(0,0,0,0.5), 0 8px 20px rgba(0,0,0,0.4);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .box-badge {
      background: rgba(9, 9, 11, 0.95);
      border: 1px solid #3f3f46;
      color: #fafafa;
      font-family: monospace;
      font-size: 11px;
      font-weight: bold;
      padding: 2px 6px;
      border-radius: 4px;
      pointer-events: none;
    }
    .resize-handle {
      position: absolute;
      width: 8px;
      height: 8px;
      background: #ffffff;
      border: 1.5px solid #09090b;
      border-radius: 1px;
      z-index: 25;
    }
    .resize-handle:hover { transform: scale(1.3); }
    .handle-nw { top: -4px; left: -4px; cursor: nwse-resize; }
    .handle-ne { top: -4px; right: -4px; cursor: nesw-resize; }
    .handle-sw { bottom: -4px; left: -4px; cursor: nesw-resize; }
    .handle-se { bottom: -4px; right: -4px; cursor: nwse-resize; }
    .handle-t { top: -4px; left: 50%; transform: translateX(-50%); width: 14px; height: 5px; cursor: ns-resize; }
    .handle-b { bottom: -4px; left: 50%; transform: translateX(-50%); width: 14px; height: 5px; cursor: ns-resize; }
    .handle-l { left: -4px; top: 50%; transform: translateY(-50%); width: 5px; height: 14px; cursor: ew-resize; }
    .handle-r { right: -4px; top: 50%; transform: translateY(-50%); width: 5px; height: 14px; cursor: ew-resize; }
    .panel {
      position: fixed;
      bottom: 24px;
      right: 24px;
      width: 420px;
      max-width: calc(100vw - 32px);
      background: #18181b;
      color: #fafafa;
      border: 1px solid #3f3f46;
      border-radius: 14px;
      box-shadow: 0 20px 35px -5px rgba(0, 0, 0, 0.8);
      pointer-events: auto;
      overflow: hidden;
      font-size: 13px;
      z-index: 100;
      box-sizing: border-box;
    }
    .panel-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px 14px;
      background: #27272a;
      border-bottom: 1px solid #3f3f46;
      cursor: move;
      user-select: none;
      box-sizing: border-box;
      flex-shrink: 0;
    }
    .panel-controls {
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .icon-btn {
      background: transparent;
      border: none;
      color: #a1a1aa;
      cursor: pointer;
      padding: 3px 6px;
      border-radius: 4px;
      font-size: 12px;
      font-weight: bold;
    }
    .icon-btn:hover { background: #3f3f46; color: #fafafa; }
    .panel-body {
      padding: 12px 14px;
      max-height: 75vh;
      overflow-y: auto;
      overflow-x: hidden;
      box-sizing: border-box;
    }
    .grid-4 {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 6px;
      margin-bottom: 10px;
    }
    .metric-card {
      background: #09090b;
      border: 1px solid #27272a;
      padding: 6px 8px;
      border-radius: 8px;
      min-width: 0;
      box-sizing: border-box;
      overflow: hidden;
    }
    .metric-title {
      font-size: 11px;
      color: #a1a1aa;
      font-weight: 600;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .metric-val {
      font-size: 14px;
      font-weight: 700;
      color: #fafafa;
      margin-top: 2px;
      font-family: monospace;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .code-box {
      background: #09090b;
      border: 1px solid #27272a;
      border-radius: 6px;
      padding: 8px 10px;
      font-family: monospace;
      color: #34d399;
      word-break: break-all;
      overflow-x: auto;
      max-width: 100%;
      box-sizing: border-box;
      margin-bottom: 8px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      font-size: 12px;
    }
    .copy-btn {
      background: #27272a;
      color: #ffffff;
      border: 1px solid #3f3f46;
      padding: 3px 8px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 11.5px;
      font-weight: 600;
      white-space: nowrap;
      transition: background 0.15s;
      flex-shrink: 0;
    }
    .copy-btn:hover { background: #3f3f46; }
    .copy-btn.copied { background: #059669; border-color: #10b981; }
    .unit-switch {
      display: flex;
      background: #09090b;
      border: 1px solid #27272a;
      border-radius: 6px;
      padding: 2px;
      gap: 2px;
      flex-shrink: 0;
    }
    .tab-switch {
      display: flex;
      background: #09090b;
      border: 1px solid #27272a;
      border-radius: 8px;
      padding: 3px;
      gap: 3px;
      overflow-x: auto;
      white-space: nowrap;
      max-width: 100%;
      box-sizing: border-box;
      scrollbar-width: thin;
      scrollbar-color: #3f3f46 #09090b;
    }
    .tab-switch::-webkit-scrollbar {
      height: 3px;
    }
    .tab-switch::-webkit-scrollbar-thumb {
      background: #3f3f46;
      border-radius: 3px;
    }
    .pill-btn {
      background: transparent;
      border: none;
      color: #a1a1aa;
      padding: 3px 7px;
      font-size: 10.5px;
      font-weight: 600;
      border-radius: 5px;
      cursor: pointer;
      flex-shrink: 0;
      transition: background 0.15s, color 0.15s;
    }
    .pill-btn.active {
      background: #3f3f46;
      color: #ffffff;
    }
    .detached-nudge-window {
      position: fixed;
      bottom: 24px;
      right: 460px;
      width: 310px;
      background: #09090b;
      color: #fafafa;
      border: 1px solid #3f3f46;
      border-radius: 12px;
      box-shadow: 0 12px 32px rgba(0, 0, 0, 0.85);
      pointer-events: auto;
      z-index: 101;
      box-sizing: border-box;
      display: none;
      overflow: hidden;
    }
    .nudge-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 8px 12px;
      background: #18181b;
      border-bottom: 1px solid #27272a;
      cursor: move;
      user-select: none;
      font-size: 11px;
      font-weight: 700;
      color: #e4e4e7;
    }
    .nudge-body {
      padding: 10px;
    }
    .nudge-btn {
      background: #18181b;
      border: 1px solid #27272a;
      color: #f4f4f5;
      padding: 4px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 700;
      cursor: pointer;
      text-align: center;
      transition: background 0.15s, border-color 0.15s;
    }
    .nudge-btn:hover { background: #27272a; border-color: #52525b; color: #ffffff; }
    .nudge-btn:active { background: #3f3f46; }
  `;
  shadow.appendChild(style);
  const container = document.createElement('div');
  container.innerHTML = `
    <div class="overlay" id="ruler-overlay"></div>
    <div class="top-banner">
      <div style="display: flex; align-items: center; gap: 6px; color: #fafafa; font-weight: 700;">
        <span class="status-dot"></span>
        <span>外枠px逆算定規 稼働中</span>
      </div>
      <span style="color: #52525b;">|</span>
      <span style="color: #d4d4d8; font-size: 11px;">ドラッグで枠描画 / クリックで要素選択</span>
      <span style="color: #52525b;">|</span>
      <span style="color: #a1a1aa; font-size: 11px;">Shift+ドラッグ: スナップ & 軸固定</span>
      <span style="color: #52525b;">|</span>
      <button class="btn-close-top" id="btn-close-banner">✕ 終了 (Esc)</button>
    </div>
    <svg class="ruler-svg" id="ruler-svg"></svg>
    <div id="selected-box-wrapper"></div>
    <!-- 切り離し用の位置・サイズ微調整ミニウィンドウ -->
    <div class="detached-nudge-window" id="detached-nudge-window">
      <div class="nudge-header" id="nudge-window-header">
        <div style="display:flex; align-items:center; gap:6px;">
          <span style="color:#60a5fa; font-size:12px;">✥</span>
          <span>位置・サイズ微調整</span>
        </div>
        <div style="display:flex; align-items:center; gap:4px;">
          <button class="pill-btn" id="btn-dock-nudge" title="メインパネル内に戻す" style="padding:2px 6px; font-size:10px; background:#18181b; color:#38bdf8; border:1px solid #0284c7;">↙ ドック</button>
          <button class="icon-btn" id="btn-close-detached" title="${t('close')}">✕</button>
        </div>
      </div>
      <div class="nudge-body" id="detached-nudge-body"></div>
    </div>
    <div class="panel" id="ruler-panel">
      <div class="panel-header" id="panel-header">
        <div style="display: flex; align-items: center; gap: 6px;">
          <span style="font-weight: 700; color: #fafafa;">${t('panelTitle')}</span>
          <span id="panel-badge" style="background:#09090b; border:1px solid #3f3f46; padding:1px 5px; border-radius:4px; font-size:10px; font-family:monospace;">${t('waiting')}</span>
        </div>
        <div class="panel-controls" style="display:flex; align-items:center; gap:4px;">
          <button class="icon-btn" id="btn-open-settings" title="${t('settings')}" style="display:flex; align-items:center; justify-content:center; width:22px; height:22px; font-size:11px; font-weight:bold;">SET</button>
          <button class="icon-btn" id="btn-min-panel" title="${t('minimize')}">_</button>
          <button class="icon-btn" id="btn-close-panel" title="${t('close')}">✕</button>
        </div>
      </div>
      <!-- 拡張機能設定ドロワー -->
      <div id="settings-drawer" style="display:none; background:#18181b; border-bottom:1px solid #27272a; padding:10px 12px; font-size:12px;">
        <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:8px;">
          <span style="font-weight:700; color:#fafafa; display:flex; align-items:center; gap:6px;">
            ${t('drawerTitle')}
          </span>
          <span style="font-size:10px; color:#71717a;">${t('realtimeReflection')}</span>
        </div>
        <div style="display:flex; align-items:center; justify-content:space-between; background:#09090b; border:1px solid #27272a; border-radius:8px; padding:8px 10px;">
          <div>
            <div style="font-weight:600; color:#f4f4f5;">${t('dualGuideTitle')}</div>
            <div style="font-size:10px; color:#a1a1aa;">${t('dualGuideDesc')}</div>
          </div>
          <button id="btn-toggle-dual-distance" style="position:relative; width:44px; height:24px; border-radius:12px; border:none; background:#f59e0b; cursor:pointer; padding:2px; transition:background 0.2s ease-in-out;">
            <span id="toggle-knob-dual" style="display:flex; align-items:center; justify-content:center; width:20px; height:20px; border-radius:10px; background:#ffffff; color:#d97706; font-size:9px; font-weight:700; transform:translateX(20px); transition:transform 0.2s ease-in-out;">ON</span>
          </button>
        </div>
      </div>
      <div class="panel-body" id="panel-content">
        <div style="color: #a1a1aa; padding: 10px 0; line-height: 1.6;">
          <p style="color: #ffffff; font-weight: 700; margin-bottom: 4px;">${t('measureWaiting')}</p>
          <p>${t('dragOrClickDesc')}</p>
        </div>
      </div>
    </div>
  `;
  shadow.appendChild(container);
  const svg = shadow.getElementById('ruler-svg');
  const panel = shadow.getElementById('ruler-panel');
  const panelHeader = shadow.getElementById('panel-header');
  const panelContent = shadow.getElementById('panel-content');
  const panelBadge = shadow.getElementById('panel-badge');
  const selectedBoxWrapper = shadow.getElementById('selected-box-wrapper');
  const btnCloseBanner = shadow.getElementById('btn-close-banner');
  const btnClosePanel = shadow.getElementById('btn-close-panel');
  const btnMinPanel = shadow.getElementById('btn-min-panel');
  const detachedWindow = shadow.getElementById('detached-nudge-window');
  const nudgeWindowHeader = shadow.getElementById('nudge-window-header');
  const detachedNudgeBody = shadow.getElementById('detached-nudge-body');
  const btnDockNudge = shadow.getElementById('btn-dock-nudge');
  const btnCloseDetached = shadow.getElementById('btn-close-detached');
  const btnOpenSettings = shadow.getElementById('btn-open-settings');
  const settingsDrawer = shadow.getElementById('settings-drawer');
  const btnToggleDualDistance = shadow.getElementById('btn-toggle-dual-distance');
  const toggleKnobDual = shadow.getElementById('toggle-knob-dual');
  let isNudgeDetached = false;
  let isSettingsOpen = false;
  let showDualDistance = true;
  if (btnOpenSettings && settingsDrawer) {
    btnOpenSettings.addEventListener('click', () => {
      isSettingsOpen = !isSettingsOpen;
      settingsDrawer.style.display = isSettingsOpen ? 'block' : 'none';
      btnOpenSettings.style.color = isSettingsOpen ? '#f59e0b' : '#a1a1aa';
    });
  }
  if (btnToggleDualDistance && toggleKnobDual) {
    btnToggleDualDistance.addEventListener('click', () => {
      showDualDistance = !showDualDistance;
      if (showDualDistance) {
        btnToggleDualDistance.style.background = '#f59e0b';
        toggleKnobDual.style.transform = 'translateX(20px)';
        toggleKnobDual.style.color = '#d97706';
        toggleKnobDual.textContent = 'ON';
      } else {
        btnToggleDualDistance.style.background = '#3f3f46';
        toggleKnobDual.style.transform = 'translateX(0px)';
        toggleKnobDual.style.color = '#71717a';
        toggleKnobDual.textContent = 'OFF';
      }
      if (currentBox) {
        renderAll(currentBox);
      }
    });
  }
  function toggleRuler() {
    isActive = !isActive;
    if (isActive) {
      attachHost();
      host.style.display = 'block';
      host.style.pointerEvents = 'auto';
      panel.style.display = 'block';
      if (!currentBox) {
        showEmpty();
      } else {
        renderAll(currentBox);
      }
    } else {
      host.style.display = 'none';
      host.style.pointerEvents = 'none';
      clearAll();
    }
  }
  window.__OUTER_BOX_RULER_TOGGLE__ = toggleRuler;
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (msg.type === 'TOGGLE_RULER') {
        toggleRuler();
        sendResponse({ success: true, active: isActive });
      }
      return true;
    });
  }
  function handleViewportChange() {
    if (!isActive || !currentBox) return;
    if (selectedElement && document.body.contains(selectedElement)) {
      const r = selectedElement.getBoundingClientRect();
      if (r.width >= 2 && r.height >= 2) {
        currentBox = {
          x: r.left,
          y: r.top,
          width: r.width,
          height: r.height,
          left: r.left,
          top: r.top,
          right: r.right,
          bottom: r.bottom,
        };
      }
    }
    renderAll(currentBox);
  }
  window.addEventListener('scroll', handleViewportChange, { capture: true, passive: true });
  window.addEventListener('resize', handleViewportChange);
  function showEmpty() {
    panelBadge.textContent = t('waiting');
    panelContent.innerHTML = `
      <div style="color: #a1a1aa; padding: 10px 0; line-height: 1.6;">
        <p style="color: #ffffff; font-weight: 700; margin-bottom: 4px;">${t('measureWaiting')}</p>
        <p>${t('dragOrClickDesc')}</p>
        <p style="margin-top:8px; font-size:11px; color:#71717a;">${t('shortcutDesc')}</p>
      </div>
    `;
  }
  function clearAll() {
    svg.innerHTML = '';
    selectedBoxWrapper.innerHTML = '';
    currentBox = null;
    selectedElement = null;
  }
  btnCloseBanner.addEventListener('click', (e) => { e.stopPropagation(); toggleRuler(); });
  btnClosePanel.addEventListener('click', (e) => { e.stopPropagation(); toggleRuler(); });
  btnMinPanel.addEventListener('click', (e) => {
    e.stopPropagation();
    isPanelMinimized = !isPanelMinimized;
    panelContent.style.display = isPanelMinimized ? 'none' : 'block';
    btnMinPanel.textContent = isPanelMinimized ? '□' : '_';
  });
  let isPanelDragging = false;
  let pOffX = 0, pOffY = 0;
  panelHeader.addEventListener('mousedown', (e) => {
    if (e.target.tagName.toLowerCase() === 'button') return;
    isPanelDragging = true;
    const r = panel.getBoundingClientRect();
    pOffX = e.clientX - r.left;
    pOffY = e.clientY - r.top;
  });
  window.addEventListener('mousemove', (e) => {
    if (!isPanelDragging) return;
    panel.style.left = Math.max(10, Math.min(window.innerWidth - panel.offsetWidth - 10, e.clientX - pOffX)) + 'px';
    panel.style.top = Math.max(10, Math.min(window.innerHeight - panel.offsetHeight - 10, e.clientY - pOffY)) + 'px';
    panel.style.right = 'auto';
    panel.style.bottom = 'auto';
  });
  window.addEventListener('mouseup', () => { isPanelDragging = false; });
  function nudgeBox(dx = 0, dy = 0, dw = 0, dh = 0) {
    if (!currentBox) return;
    const nw = Math.max(4, Math.round(currentBox.width + dw));
    const nh = Math.max(4, Math.round(currentBox.height + dh));
    const nx = Math.round(currentBox.x + dx);
    const ny = Math.round(currentBox.y + dy);
    currentBox = {
      x: nx,
      y: ny,
      width: nw,
      height: nh,
      left: nx,
      top: ny,
      right: nx + nw,
      bottom: ny + nh
    };
    renderAll(currentBox);
  }
  let isNudgeDragging = false;
  let nOffX = 0, nOffY = 0;
  nudgeWindowHeader?.addEventListener('mousedown', (e) => {
    if (e.target.tagName.toLowerCase() === 'button') return;
    isNudgeDragging = true;
    const r = detachedWindow.getBoundingClientRect();
    nOffX = e.clientX - r.left;
    nOffY = e.clientY - r.top;
  });
  window.addEventListener('mousemove', (e) => {
    if (!isNudgeDragging) return;
    detachedWindow.style.left = Math.max(10, Math.min(window.innerWidth - detachedWindow.offsetWidth - 10, e.clientX - nOffX)) + 'px';
    detachedWindow.style.top = Math.max(10, Math.min(window.innerHeight - detachedWindow.offsetHeight - 10, e.clientY - nOffY)) + 'px';
    detachedWindow.style.right = 'auto';
    detachedWindow.style.bottom = 'auto';
  });
  window.addEventListener('mouseup', () => { isNudgeDragging = false; });
  btnDockNudge?.addEventListener('click', () => {
    isNudgeDetached = false;
    detachedWindow.style.display = 'none';
    if (currentBox) renderAll(currentBox);
  });
  btnCloseDetached?.addEventListener('click', () => {
    isNudgeDetached = false;
    detachedWindow.style.display = 'none';
    if (currentBox) renderAll(currentBox);
  });
  window.addEventListener('keydown', (e) => {
    if (!isActive) return;
    if (e.key === 'Escape') { toggleRuler(); return; }
    if (!currentBox) return;
    const step = e.shiftKey ? 10 : 1;
    let b = { ...currentBox };
    if (e.altKey) {
      if (e.key === 'ArrowRight') b.width += step;
      if (e.key === 'ArrowLeft') b.width = Math.max(4, b.width - step);
      if (e.key === 'ArrowDown') b.height += step;
      if (e.key === 'ArrowUp') b.height = Math.max(4, b.height - step);
    } else if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
      if (e.key === 'ArrowRight') b.x += step;
      if (e.key === 'ArrowLeft') b.x -= step;
      if (e.key === 'ArrowDown') b.y += step;
      if (e.key === 'ArrowUp') b.y -= step;
    } else {
      return;
    }
    e.preventDefault();
    b.left = b.x; b.top = b.y; b.right = b.x + b.width; b.bottom = b.y + b.height;
    currentBox = b;
    renderAll(currentBox);
  });
  function calculateSnap(val, step = 8) {
    return Math.round(val / step) * step;
  }
  shadow.getElementById('ruler-overlay').addEventListener('mousedown', (e) => {
    if (!isActive || e.button !== 0) return;
    e.preventDefault();
    isInteracting = true;
    interactMode = 'draw';
    startX = e.clientX;
    startY = e.clientY;
    initialBox = null;
    selectedElement = null;
  });
  window.addEventListener('mousemove', (e) => {
    if (!isActive || !isInteracting) return;
    const isShift = e.shiftKey || snapGrid !== 'none';
    const gridStep = snapGrid === '4px' ? 4 : 8;
    if (interactMode === 'draw') {
      let rawW = Math.abs(e.clientX - startX);
      let rawH = Math.abs(e.clientY - startY);
      if (e.shiftKey) {
        const maxSide = Math.max(rawW, rawH);
        const snappedSide = Math.max(8, calculateSnap(maxSide, 8));
        rawW = snappedSide;
        rawH = snappedSide;
      } else if (snapGrid !== 'none') {
        rawW = Math.max(gridStep, calculateSnap(rawW, gridStep));
        rawH = Math.max(gridStep, calculateSnap(rawH, gridStep));
      }
      if (rawW >= 3 || rawH >= 3) {
        let x = e.clientX >= startX ? startX : startX - rawW;
        let y = e.clientY >= startY ? startY : startY - rawH;
        if (isShift) {
          x = calculateSnap(x, gridStep);
          y = calculateSnap(y, gridStep);
        }
        currentBox = { x, y, width: rawW, height: rawH, top: y, left: x, right: x + rawW, bottom: y + rawH };
        renderAll(currentBox);
      }
    } else if (interactMode === 'move' && initialBox) {
      let dx = e.clientX - startX;
      let dy = e.clientY - startY;
      if (e.shiftKey) {
        if (Math.abs(dx) > Math.abs(dy)) {
          dy = 0;
        } else {
          dx = 0;
        }
      }
      let nx = initialBox.x + dx;
      let ny = initialBox.y + dy;
      if (isShift) {
        nx = calculateSnap(nx, gridStep);
        ny = calculateSnap(ny, gridStep);
      }
      currentBox = { x: nx, y: ny, width: initialBox.width, height: initialBox.height, left: nx, top: ny, right: nx + initialBox.width, bottom: ny + initialBox.height };
      renderAll(currentBox);
    } else if (interactMode === 'resize' && initialBox && resizeHandle) {
      let dx = e.clientX - startX;
      let dy = e.clientY - startY;
      let { x, y, width, height } = initialBox;
      if (e.shiftKey && (resizeHandle.length === 2)) {
        const ratio = initialBox.width / initialBox.height;
        if (Math.abs(dx) > Math.abs(dy)) {
          dy = dx / ratio;
        } else {
          dx = dy * ratio;
        }
      }
      if (resizeHandle.includes('r') || resizeHandle.includes('e')) width = Math.max(4, initialBox.width + dx);
      if (resizeHandle.includes('b') || resizeHandle.includes('s')) height = Math.max(4, initialBox.height + dy);
      if (resizeHandle.includes('l') || resizeHandle.includes('w')) {
        const nw = Math.max(4, initialBox.width - dx);
        x = initialBox.x + (initialBox.width - nw);
        width = nw;
      }
      if (resizeHandle.includes('t') || resizeHandle.includes('n')) {
        const nh = Math.max(4, initialBox.height - dy);
        y = initialBox.y + (initialBox.height - nh);
        height = nh;
      }
      if (isShift) {
        width = Math.max(gridStep, calculateSnap(width, gridStep));
        height = Math.max(gridStep, calculateSnap(height, gridStep));
      }
      currentBox = { x, y, width, height, left: x, top: y, right: x + width, bottom: y + height };
      renderAll(currentBox);
    }
  });
  window.addEventListener('mouseup', (e) => {
    if (!isActive || !isInteracting) return;
    const mode = interactMode;
    isInteracting = false;
    interactMode = null;
    initialBox = null;
    resizeHandle = null;
    if (mode === 'draw') {
      const dist = Math.hypot(e.clientX - startX, e.clientY - startY);
      if (dist < 4) {
        const elements = document.elementsFromPoint(e.clientX, e.clientY);
        let targetEl = null;
        for (const el of elements) {
          if (el === host || host.contains(el)) continue;
          if (['html', 'body'].includes(el.tagName.toLowerCase())) continue;
          const style = window.getComputedStyle(el);
          if (style.display === 'none' || style.visibility === 'hidden' || style.pointerEvents === 'none') continue;
          targetEl = el;
          break;
        }
        if (targetEl) {
          selectedElement = targetEl;
          const r = targetEl.getBoundingClientRect();
          if (r.width >= 2 && r.height >= 2) {
            currentBox = { x: r.left, y: r.top, width: r.width, height: r.height, left: r.left, top: r.top, right: r.right, bottom: r.bottom };
            renderAll(currentBox);
          }
        }
      }
    }
  });
  function findParentContainer(box) {
    if (selectedElement && selectedElement.parentElement && selectedElement.parentElement !== document.documentElement) {
      return selectedElement.parentElement;
    }
    const cx = box.x + box.width / 2;
    const cy = box.y + box.height / 2;
    const pts = [
      { x: cx, y: cy },
      { x: box.x + 2, y: box.y + 2 },
      { x: box.right - 2, y: box.y + 2 },
      { x: box.x + 2, y: box.bottom - 2 },
      { x: box.right - 2, y: box.bottom - 2 },
    ];
    let minArea = Infinity;
    let bestParent = null;
    for (const pt of pts) {
      if (pt.x < 0 || pt.y < 0 || pt.x > window.innerWidth || pt.y > window.innerHeight) continue;
      const elements = document.elementsFromPoint(pt.x, pt.y);
      for (const el of elements) {
        if (el === host || host.contains(el)) continue;
        if (['html'].includes(el.tagName.toLowerCase())) continue;
        const style = window.getComputedStyle(el);
        if (style.display === 'none' || style.visibility === 'hidden' || style.pointerEvents === 'none') continue;
        const b = el.getBoundingClientRect();
        const contains = b.left <= box.left + 1.5 && b.right >= box.right - 1.5 && b.top <= box.top + 1.5 && b.bottom >= box.bottom - 1.5;
        if (contains) {
          const area = b.width * b.height;
          if (area > 0 && area < minArea) {
            minArea = area;
            bestParent = el;
          }
        }
      }
    }
    return bestParent || document.body || document.documentElement;
  }
  function findContainingBlock(parentEl) {
    let curr = parentEl;
    while (curr && curr !== document.documentElement && curr !== document.body) {
      const style = window.getComputedStyle(curr);
      if (style.position !== 'static') {
        return { element: curr, reason: 'position: ' + style.position, property: 'position', value: style.position };
      }
      if (style.transform !== 'none' || style.perspective !== 'none' || (style.transformStyle && style.transformStyle === 'preserve-3d')) {
        return { element: curr, reason: 'transform: ' + style.transform, property: 'transform', value: style.transform };
      }
      if (style.filter !== 'none' || style.backdropFilter !== 'none') {
        return { element: curr, reason: 'filter: ' + style.filter, property: 'filter', value: style.filter };
      }
      if (style.contain && style.contain !== 'none') {
        const c = style.contain;
        if (c.includes('paint') || c.includes('layout') || c.includes('strict') || c.includes('content')) {
          return { element: curr, reason: 'contain: ' + c, property: 'contain', value: c };
        }
      }
      const ct = style.getPropertyValue('container-type');
      if (ct && ct !== 'normal' && ct !== '') {
        return { element: curr, reason: 'container-type: ' + ct, property: 'container-type', value: ct };
      }
      const cv = style.getPropertyValue('content-visibility');
      if (cv === 'auto') {
        return { element: curr, reason: 'content-visibility: auto', property: 'content-visibility', value: 'auto' };
      }
      if (style.willChange && style.willChange !== 'auto') {
        const wc = style.willChange;
        if (wc.includes('transform') || wc.includes('perspective') || wc.includes('filter') || wc.includes('contain')) {
          return { element: curr, reason: 'will-change: ' + wc, property: 'will-change', value: wc };
        }
      }
      curr = curr.parentElement;
    }
    return { element: document.documentElement, reason: 'Initial Containing Block (Viewport / Root)', property: 'root', value: 'viewport' };
  }
  function findNearbyContainers(box, parentEl) {
    const nearby = { left: null, right: null, top: null, bottom: null };
    const vpW = window.innerWidth;
    const vpH = window.innerHeight;
    const midY = box.y + box.height / 2;
    const midX = box.x + box.width / 2;
    for (let x = box.left - 5; x >= 0; x -= 12) {
      const els = document.elementsFromPoint(x, midY);
      for (const el of els) {
        if (el === host || host.contains(el) || el === parentEl || el.contains(parentEl)) continue;
        const tag = el.tagName.toLowerCase();
        if (['html', 'body'].includes(tag)) continue;
        const style = window.getComputedStyle(el);
        if (style.display === 'none' || style.visibility === 'hidden' || style.pointerEvents === 'none') continue;
        const r = el.getBoundingClientRect();
        if (r.width >= 16 && r.height >= 16 && r.right <= box.left + 2) {
          const dist = Math.round(box.left - r.right);
          if (dist >= 0 && (!nearby.left || dist < nearby.left.distance)) {
            nearby.left = { element: el, tagName: tag, distance: dist, rect: r };
          }
        }
      }
      if (nearby.left) break;
    }
    for (let x = box.right + 5; x <= vpW; x += 12) {
      const els = document.elementsFromPoint(x, midY);
      for (const el of els) {
        if (el === host || host.contains(el) || el === parentEl || el.contains(parentEl)) continue;
        const tag = el.tagName.toLowerCase();
        if (['html', 'body'].includes(tag)) continue;
        const style = window.getComputedStyle(el);
        if (style.display === 'none' || style.visibility === 'hidden' || style.pointerEvents === 'none') continue;
        const r = el.getBoundingClientRect();
        if (r.width >= 16 && r.height >= 16 && r.left >= box.right - 2) {
          const dist = Math.round(r.left - box.right);
          if (dist >= 0 && (!nearby.right || dist < nearby.right.distance)) {
            nearby.right = { element: el, tagName: tag, distance: dist, rect: r };
          }
        }
      }
      if (nearby.right) break;
    }
    for (let y = box.top - 5; y >= 0; y -= 12) {
      const els = document.elementsFromPoint(midX, y);
      for (const el of els) {
        if (el === host || host.contains(el) || el === parentEl || el.contains(parentEl)) continue;
        const tag = el.tagName.toLowerCase();
        if (['html', 'body'].includes(tag)) continue;
        const style = window.getComputedStyle(el);
        if (style.display === 'none' || style.visibility === 'hidden' || style.pointerEvents === 'none') continue;
        const r = el.getBoundingClientRect();
        if (r.width >= 16 && r.height >= 16 && r.bottom <= box.top + 2) {
          const dist = Math.round(box.top - r.bottom);
          if (dist >= 0 && (!nearby.top || dist < nearby.top.distance)) {
            nearby.top = { element: el, tagName: tag, distance: dist, rect: r };
          }
        }
      }
      if (nearby.top) break;
    }
    for (let y = box.bottom + 5; y <= vpH; y += 12) {
      const els = document.elementsFromPoint(midX, y);
      for (const el of els) {
        if (el === host || host.contains(el) || el === parentEl || el.contains(parentEl)) continue;
        const tag = el.tagName.toLowerCase();
        if (['html', 'body'].includes(tag)) continue;
        const style = window.getComputedStyle(el);
        if (style.display === 'none' || style.visibility === 'hidden' || style.pointerEvents === 'none') continue;
        const r = el.getBoundingClientRect();
        if (r.width >= 16 && r.height >= 16 && r.top >= box.bottom - 2) {
          const dist = Math.round(r.top - box.bottom);
          if (dist >= 0 && (!nearby.bottom || dist < nearby.bottom.distance)) {
            nearby.bottom = { element: el, tagName: tag, distance: dist, rect: r };
          }
        }
      }
      if (nearby.bottom) break;
    }
    return nearby;
  }
  function renderAll(box) {
    if (!box || box.width < 4 || box.height < 4) return;
    let calcBox = { ...box };
    if (snapGrid === '4px') {
      calcBox.width = Math.round(box.width / 4) * 4;
      calcBox.height = Math.round(box.height / 4) * 4;
    } else if (snapGrid === '8px') {
      calcBox.width = Math.round(box.width / 8) * 8;
      calcBox.height = Math.round(box.height / 8) * 8;
    }
    panelBadge.textContent = `${Math.round(calcBox.width)} × ${Math.round(calcBox.height)}`;
    selectedBoxWrapper.innerHTML = `
      <div class="selected-box" id="box-el" style="left:${box.x}px; top:${box.y}px; width:${box.width}px; height:${box.height}px;">
        <div class="box-badge">${Math.round(calcBox.width)} × ${Math.round(calcBox.height)}</div>
        <div class="resize-handle handle-nw" data-handle="nw"></div>
        <div class="resize-handle handle-ne" data-handle="ne"></div>
        <div class="resize-handle handle-sw" data-handle="sw"></div>
        <div class="resize-handle handle-se" data-handle="se"></div>
        <div class="resize-handle handle-t" data-handle="t"></div>
        <div class="resize-handle handle-b" data-handle="b"></div>
        <div class="resize-handle handle-l" data-handle="l"></div>
        <div class="resize-handle handle-r" data-handle="r"></div>
      </div>
    `;
    const boxEl = shadow.getElementById('box-el');
    boxEl.addEventListener('mousedown', (e) => {
      if (e.target.dataset.handle) {
        e.stopPropagation(); e.preventDefault();
        isInteracting = true;
        interactMode = 'resize';
        resizeHandle = e.target.dataset.handle;
        startX = e.clientX; startY = e.clientY;
        initialBox = { ...currentBox };
        return;
      }
      e.stopPropagation(); e.preventDefault();
      isInteracting = true;
      interactMode = 'move';
      startX = e.clientX; startY = e.clientY;
      initialBox = { ...currentBox };
    });
    const parentEl = findParentContainer(calcBox);
    const cbObj = findContainingBlock(parentEl);
    const cbEl = cbObj ? cbObj.element : document.documentElement;
    const pRect = parentEl.getBoundingClientRect();
    const cbRect = cbEl.getBoundingClientRect();
    const style = window.getComputedStyle(parentEl);
    const pt = parseFloat(style.paddingTop) || 0;
    const pl = parseFloat(style.paddingLeft) || 0;
    const topDist = Math.round(calcBox.top - pRect.top);
    const leftDist = Math.round(calcBox.left - pRect.left);
    const rightDist = Math.round(pRect.right - calcBox.right);
    const bottomDist = Math.round(pRect.bottom - calcBox.bottom);
    const absTop = Math.round(calcBox.top - cbRect.top);
    const absLeft = Math.round(calcBox.left - cbRect.left);
    const absRight = Math.round(cbRect.right - calcBox.right);
    const absBottom = Math.round(cbRect.bottom - calcBox.bottom);
    const topContent = Math.max(0, topDist - pt);
    const leftContent = Math.max(0, leftDist - pl);
    const nearby = findNearbyContainers(calcBox, parentEl);
    const pTag = parentEl.tagName.toLowerCase();
    const pClass = parentEl.className && typeof parentEl.className === 'string' ? '.' + parentEl.className.trim().split(/s+/)[0] : '';
    const pId = parentEl.id ? '#' + parentEl.id : '';
    const pLabelText = t('parent') + ': <' + pTag + '>' + (pId || pClass);
    const pLabelEscaped = t('parent') + ': &lt;' + pTag + '&gt;' + (pId || pClass);
    const pLabelWidth = Math.min(320, Math.max(120, pLabelText.length * 8));
    let svgHtml = `
      <rect x="${pRect.left}" y="${pRect.top}" width="${pRect.width}" height="${pRect.height}" 
        fill="rgba(59, 130, 246, 0.03)" stroke="#60a5fa" stroke-width="1.5" stroke-dasharray="4,4" />
      <g transform="translate(${pRect.left + 6}, ${Math.max(20, pRect.top + 16)})">
        <rect x="0" y="-12" width="${pLabelWidth}" height="18" rx="3" fill="#18181b" stroke="#3b82f6" stroke-width="1" />
        <text x="5" y="1" fill="#e4e4e7" font-size="11" font-weight="700">
          ${pLabelEscaped}
        </text>
      </g>
    `;
    const centerX = calcBox.x + calcBox.width / 2;
    const centerY = calcBox.top + calcBox.height / 2;
    const leftBadgeY = calcBox.width < 120 ? centerY - 18 : centerY;
    const rightBadgeY = calcBox.width < 120 ? centerY + 18 : centerY;
    const hasNearbyLeft = showDualDistance && nearby && nearby.left && nearby.left.distance >= 0 && nearby.left.rect.right <= calcBox.left + 1;
    const hasNearbyRight = showDualDistance && nearby && nearby.right && nearby.right.distance >= 0 && nearby.right.rect.left >= calcBox.right - 1;
    const hasNearbyTop = showDualDistance && nearby && nearby.top && nearby.top.distance >= 0 && nearby.top.rect.bottom <= calcBox.top + 1;
    const hasNearbyBottom = showDualDistance && nearby && nearby.bottom && nearby.bottom.distance >= 0 && nearby.bottom.rect.top >= calcBox.bottom - 1;
    if (hasNearbyTop && nearby.top) {
      const seg1Dist = Math.round(nearby.top.distance);
      const parentTopY = pRect ? pRect.top : 0;
      const seg2Dist = pRect && parentTopY < nearby.top.rect.bottom ? Math.round(nearby.top.rect.bottom - parentTopY) : 0;
      svgHtml += `
        <!-- 近接要素の領域ハイライト -->
        <rect x="${nearby.top.rect.left}" y="${nearby.top.rect.top}" width="${nearby.top.rect.width}" height="${nearby.top.rect.height}"
          fill="rgba(16, 185, 129, 0.06)" stroke="#10b981" stroke-width="1.5" stroke-dasharray="3,3" />
        <!-- 第一段階: 選択枠 ➔ 隣接要素の下端 (エメラルドグリーン) -->
        <line x1="${centerX}" y1="${calcBox.top}" x2="${centerX}" y2="${nearby.top.rect.bottom}" stroke="#10b981" stroke-width="2" />
        <circle cx="${centerX}" cy="${calcBox.top}" r="3.5" fill="#10b981" />
        <circle cx="${centerX}" cy="${nearby.top.rect.bottom}" r="3.5" fill="#10b981" />
        <g transform="translate(${centerX}, ${(calcBox.top + nearby.top.rect.bottom) / 2})">
          <rect x="-40" y="-10" width="80" height="20" rx="4" fill="#09090b" stroke="#10b981" stroke-width="1.5" />
          <text x="0" y="4" fill="#6ee7b7" font-size="10" font-weight="700" text-anchor="middle">${t('adjTop')} ${seg1Dist}px</text>
        </g>
      `;
      if (pRect && parentTopY < nearby.top.rect.bottom && seg2Dist > 0) {
        svgHtml += `
          <!-- 第二段階: 隣接要素 ➔ 親コンテナの上端 (アンバーイエロー破線) -->
          <line x1="${centerX}" y1="${nearby.top.rect.bottom}" x2="${centerX}" y2="${parentTopY}" stroke="#f59e0b" stroke-width="2" stroke-dasharray="4,3" />
          <circle cx="${centerX}" cy="${parentTopY}" r="3.5" fill="#f59e0b" />
          <g transform="translate(${centerX}, ${(nearby.top.rect.bottom + parentTopY) / 2})">
            <rect x="-38" y="-10" width="76" height="20" rx="4" fill="#09090b" stroke="#f59e0b" stroke-width="1.5" />
            <text x="0" y="4" fill="#fcd34d" font-size="10" font-weight="700" text-anchor="middle">${t('parentTop')} ${seg2Dist}px</text>
          </g>
        `;
      }
    } else if (topDist > 0) {
      svgHtml += `
        <!-- 単一測定 / 二段階OFF: コーラルローズ -->
        <line x1="${centerX}" y1="${pRect.top}" x2="${centerX}" y2="${calcBox.top}" stroke="#f43f5e" stroke-width="2" />
        <circle cx="${centerX}" cy="${pRect.top}" r="3.5" fill="#f43f5e" />
        <circle cx="${centerX}" cy="${calcBox.top}" r="3.5" fill="#f43f5e" />
        <g transform="translate(${centerX}, ${(pRect.top + calcBox.top) / 2})">
          <rect x="-36" y="-10" width="72" height="20" rx="4" fill="#09090b" stroke="#f43f5e" stroke-width="1.5" />
          <text x="0" y="4" fill="#fda4af" font-size="11" font-weight="700" text-anchor="middle">${t('parentTop')} ${topDist}px</text>
        </g>
      `;
    }
    if (hasNearbyLeft && nearby.left) {
      const seg1Dist = Math.round(nearby.left.distance);
      const parentLeftX = pRect ? pRect.left : 0;
      const seg2Dist = pRect && parentLeftX < nearby.left.rect.right ? Math.round(nearby.left.rect.right - parentLeftX) : 0;
      svgHtml += `
        <!-- 近接要素の領域ハイライト -->
        <rect x="${nearby.left.rect.left}" y="${nearby.left.rect.top}" width="${nearby.left.rect.width}" height="${nearby.left.rect.height}"
          fill="rgba(16, 185, 129, 0.06)" stroke="#10b981" stroke-width="1.5" stroke-dasharray="3,3" />
        <!-- 第一段階: 選択枠 ➔ 隣接要素の右端 (エメラルドグリーン) -->
        <line x1="${calcBox.left}" y1="${centerY}" x2="${nearby.left.rect.right}" y2="${centerY}" stroke="#10b981" stroke-width="2" />
        <circle cx="${calcBox.left}" cy="${centerY}" r="3.5" fill="#10b981" />
        <circle cx="${nearby.left.rect.right}" cy="${centerY}" r="3.5" fill="#10b981" />
        <g transform="translate(${(calcBox.left + nearby.left.rect.right) / 2}, ${leftBadgeY})">
          <rect x="-40" y="-10" width="80" height="20" rx="4" fill="#09090b" stroke="#10b981" stroke-width="1.5" />
          <text x="0" y="4" fill="#6ee7b7" font-size="10" font-weight="700" text-anchor="middle">${t('adjLeft')} ${seg1Dist}px</text>
        </g>
      `;
      if (pRect && parentLeftX < nearby.left.rect.right && seg2Dist > 0) {
        svgHtml += `
          <!-- 第二段階: 隣接要素 ➔ 親コンテナの左端 (アンバーイエロー破線) -->
          <line x1="${nearby.left.rect.right}" y1="${centerY}" x2="${parentLeftX}" y2="${centerY}" stroke="#f59e0b" stroke-width="2" stroke-dasharray="4,3" />
          <circle cx="${parentLeftX}" cy="${centerY}" r="3.5" fill="#f59e0b" />
          <g transform="translate(${(nearby.left.rect.right + parentLeftX) / 2}, ${leftBadgeY})">
            <rect x="-38" y="-10" width="76" height="20" rx="4" fill="#09090b" stroke="#f59e0b" stroke-width="1.5" />
            <text x="0" y="4" fill="#fcd34d" font-size="10" font-weight="700" text-anchor="middle">${t('parentLeft')} ${seg2Dist}px</text>
          </g>
        `;
      }
    } else if (leftDist > 0) {
      svgHtml += `
        <!-- 単一測定 / 二段階OFF: コーラルローズ -->
        <line x1="${pRect.left}" y1="${centerY}" x2="${calcBox.left}" y2="${centerY}" stroke="#f43f5e" stroke-width="2" />
        <circle cx="${pRect.left}" cy="${centerY}" r="3.5" fill="#f43f5e" />
        <circle cx="${calcBox.left}" cy="${centerY}" r="3.5" fill="#f43f5e" />
        <g transform="translate(${(pRect.left + calcBox.left) / 2}, ${leftBadgeY})">
          <rect x="-36" y="-10" width="72" height="20" rx="4" fill="#09090b" stroke="#f43f5e" stroke-width="1.5" />
          <text x="0" y="4" fill="#fda4af" font-size="11" font-weight="700" text-anchor="middle">${t('parentLeft')} ${leftDist}px</text>
        </g>
      `;
    }
    if (hasNearbyRight && nearby.right) {
      const seg1Dist = Math.round(nearby.right.distance);
      const parentRightX = pRect ? pRect.right : window.innerWidth;
      const seg2Dist = pRect && parentRightX > nearby.right.rect.left ? Math.round(parentRightX - nearby.right.rect.left) : 0;
      svgHtml += `
        <!-- 近接要素の領域ハイライト -->
        <rect x="${nearby.right.rect.left}" y="${nearby.right.rect.top}" width="${nearby.right.rect.width}" height="${nearby.right.rect.height}"
          fill="rgba(16, 185, 129, 0.06)" stroke="#10b981" stroke-width="1.5" stroke-dasharray="3,3" />
        <!-- 第一段階: 選択枠 ➔ 隣接要素の左端 (エメラルドグリーン) -->
        <line x1="${calcBox.right}" y1="${centerY}" x2="${nearby.right.rect.left}" y2="${centerY}" stroke="#10b981" stroke-width="2" />
        <circle cx="${calcBox.right}" cy="${centerY}" r="3.5" fill="#10b981" />
        <circle cx="${nearby.right.rect.left}" cy="${centerY}" r="3.5" fill="#10b981" />
        <g transform="translate(${(calcBox.right + nearby.right.rect.left) / 2}, ${rightBadgeY})">
          <rect x="-40" y="-10" width="80" height="20" rx="4" fill="#09090b" stroke="#10b981" stroke-width="1.5" />
          <text x="0" y="4" fill="#6ee7b7" font-size="10" font-weight="700" text-anchor="middle">${t('adjRight')} ${seg1Dist}px</text>
        </g>
      `;
      if (pRect && parentRightX > nearby.right.rect.left && seg2Dist > 0) {
        svgHtml += `
          <!-- 第二段階: 隣接要素 ➔ 親コンテナの右端 (アンバーイエロー破線) -->
          <line x1="${nearby.right.rect.left}" y1="${centerY}" x2="${parentRightX}" y2="${centerY}" stroke="#f59e0b" stroke-width="2" stroke-dasharray="4,3" />
          <circle cx="${parentRightX}" cy="${centerY}" r="3.5" fill="#f59e0b" />
          <g transform="translate(${(nearby.right.rect.left + parentRightX) / 2}, ${rightBadgeY})">
            <rect x="-38" y="-10" width="76" height="20" rx="4" fill="#09090b" stroke="#f59e0b" stroke-width="1.5" />
            <text x="0" y="4" fill="#fcd34d" font-size="10" font-weight="700" text-anchor="middle">${t('parentRight')} ${seg2Dist}px</text>
          </g>
        `;
      }
    } else if (rightDist > 0) {
      svgHtml += `
        <!-- 単一測定 / 二段階OFF: コーラルローズ -->
        <line x1="${calcBox.right}" y1="${centerY}" x2="${pRect.right}" y2="${centerY}" stroke="#f43f5e" stroke-width="2" />
        <circle cx="${calcBox.right}" cy="${centerY}" r="3.5" fill="#f43f5e" />
        <circle cx="${pRect.right}" cy="${centerY}" r="3.5" fill="#f43f5e" />
        <g transform="translate(${(calcBox.right + pRect.right) / 2}, ${rightBadgeY})">
          <rect x="-36" y="-10" width="72" height="20" rx="4" fill="#09090b" stroke="#f43f5e" stroke-width="1.5" />
          <text x="0" y="4" fill="#fda4af" font-size="11" font-weight="700" text-anchor="middle">${t('parentRight')} ${rightDist}px</text>
        </g>
      `;
    }
    if (hasNearbyBottom && nearby.bottom) {
      const seg1Dist = Math.round(nearby.bottom.distance);
      const parentBottomY = pRect ? pRect.bottom : window.innerHeight;
      const seg2Dist = pRect && parentBottomY > nearby.bottom.rect.top ? Math.round(parentBottomY - nearby.bottom.rect.top) : 0;
      svgHtml += `
        <rect x="${nearby.bottom.rect.left}" y="${nearby.bottom.rect.top}" width="${nearby.bottom.rect.width}" height="${nearby.bottom.rect.height}"
          fill="rgba(168, 85, 247, 0.06)" stroke="#a855f7" stroke-width="1.5" stroke-dasharray="3,3" />
        <line x1="${centerX}" y1="${calcBox.bottom}" x2="${centerX}" y2="${nearby.bottom.rect.top}" stroke="#a855f7" stroke-width="2" />
        <circle cx="${centerX}" cy="${calcBox.bottom}" r="3.5" fill="#a855f7" />
        <circle cx="${centerX}" cy="${nearby.bottom.rect.top}" r="3.5" fill="#a855f7" />
        <g transform="translate(${centerX}, ${(calcBox.bottom + nearby.bottom.rect.top) / 2})">
          <rect x="-38" y="-10" width="76" height="20" rx="4" fill="#18181b" stroke="#a855f7" stroke-width="1.5" />
          <text x="0" y="4" fill="#d8b4fe" font-size="10" font-weight="700" text-anchor="middle">${t('adjBottom')} ${seg1Dist}px</text>
        </g>
      `;
      if (pRect && parentBottomY > nearby.bottom.rect.top && seg2Dist > 0) {
        svgHtml += `
          <line x1="${centerX}" y1="${nearby.bottom.rect.top}" x2="${centerX}" y2="${parentBottomY}" stroke="#ec4899" stroke-width="2" stroke-dasharray="4,3" />
          <circle cx="${centerX}" cy="${parentBottomY}" r="3.5" fill="#ec4899" />
          <g transform="translate(${centerX}, ${(nearby.bottom.rect.top + parentBottomY) / 2})">
            <rect x="-38" y="-10" width="76" height="20" rx="4" fill="#18181b" stroke="#ec4899" stroke-width="1.5" />
            <text x="0" y="4" fill="#fbcfe8" font-size="10" font-weight="700" text-anchor="middle">${t('parentBottom')} ${seg2Dist}px</text>
          </g>
        `;
      }
    } else if (bottomDist > 0) {
      svgHtml += `
        <!-- 単一測定 / 二段階OFF: コーラルローズ -->
        <line x1="${centerX}" y1="${calcBox.bottom}" x2="${centerX}" y2="${pRect.bottom}" stroke="#f43f5e" stroke-width="2" />
        <circle cx="${centerX}" cy="${calcBox.bottom}" r="3.5" fill="#f43f5e" />
        <circle cx="${centerX}" cy="${pRect.bottom}" r="3.5" fill="#f43f5e" />
        <g transform="translate(${centerX}, ${(calcBox.bottom + pRect.bottom) / 2})">
          <rect x="-36" y="-10" width="72" height="20" rx="4" fill="#09090b" stroke="#f43f5e" stroke-width="1.5" />
          <text x="0" y="4" fill="#fda4af" font-size="11" font-weight="700" text-anchor="middle">${t('parentBottom')} ${bottomDist}px</text>
        </g>
      `;
    }
    svg.innerHTML = svgHtml;
    updatePanelResults({
      box: calcBox,
      parentTag: parentEl.tagName.toLowerCase(),
      topDist, leftDist, rightDist, bottomDist,
      absTop, absLeft, absRight, absBottom,
      topContent, leftContent,
      nearby,
      pWidth: pRect.width, pHeight: pRect.height,
      cbWidth: cbRect.width, cbHeight: cbRect.height,
      cbTag: cbEl.tagName.toLowerCase(),
      cbReason: cbObj ? cbObj.reason : 'Viewport'
    });
  }
  function updatePanelResults(data) {
    const { box, parentTag, topDist, leftDist, rightDist, bottomDist, absTop, absLeft, absRight, absBottom, topContent, leftContent, nearby, pWidth, pHeight, cbWidth, cbHeight, cbTag, cbReason } = data;
    const w = Math.round(box.width);
    const h = Math.round(box.height);
    const rootFs = getRootFontSize();
    const leftTagStr = nearby && nearby.left ? '&lt;' + nearby.left.tagName.toLowerCase() + '&gt;' : '';
    const rightTagStr = nearby && nearby.right ? '&lt;' + nearby.right.tagName.toLowerCase() + '&gt;' : '';
    const cbTagStr = '&lt;' + (cbTag || 'html').toLowerCase() + '&gt;';
    let wStr = `${w}px`, hStr = `${h}px`, topStr = `${topContent}px`, leftStr = `${leftContent}px`;
    let absTopStr = `${absTop}px`, absLeftStr = `${absLeft}px`;
    if (activeUnit === 'rem') {
      wStr = `${(w / rootFs).toFixed(2)}rem`;
      hStr = `${(h / rootFs).toFixed(2)}rem`;
      topStr = `${(topContent / rootFs).toFixed(2)}rem`;
      leftStr = `${(leftContent / rootFs).toFixed(2)}rem`;
      absTopStr = `${(absTop / rootFs).toFixed(2)}rem`;
      absLeftStr = `${(absLeft / rootFs).toFixed(2)}rem`;
    } else if (activeUnit === '%') {
      wStr = `${((w / (pWidth || 1)) * 100).toFixed(1)}%`;
      hStr = `${((h / (pHeight || 1)) * 100).toFixed(1)}%`;
      topStr = `${((topContent / (pHeight || 1)) * 100).toFixed(1)}%`;
      leftStr = `${((leftContent / (pWidth || 1)) * 100).toFixed(1)}%`;
      absTopStr = `${((absTop / (cbHeight || 1)) * 100).toFixed(1)}%`;
      absLeftStr = `${((absLeft / (cbWidth || 1)) * 100).toFixed(1)}%`;
    }
    const effLeft = nearby && nearby.left ? nearby.left.distance : leftContent;
    const effRight = nearby && nearby.right ? nearby.right.distance : 0;
    function toTwToken(prefix, pxVal) {
      const rounded = Math.round(pxVal);
      if (rounded <= 0) return prefix + '-0';
      if (rounded % 4 === 0) return prefix + '-' + (rounded / 4);
      if (rounded % 2 === 0 && rounded <= 12) return prefix + '-' + (rounded / 4);
      return prefix + '-[' + rounded + 'px]';
    }
    const twMarginStd = nearby && nearby.left && nearby.right
      ? `${toTwToken('ml', effLeft)} ${toTwToken('mr', effRight)} ${toTwToken('w', w)} ${toTwToken('h', h)}`
      : `${toTwToken('mt', topContent)} ${toTwToken('ml', leftContent)} ${toTwToken('w', w)} ${toTwToken('h', h)}`;
    const twMarginArb = nearby && nearby.left && nearby.right 
      ? `ml-[${effLeft}px] mr-[${effRight}px] w-[${wStr}] h-[${hStr}]`
      : `mt-[${topStr}] ml-[${leftStr}] w-[${wStr}] h-[${hStr}]`;
    const twMargin = twMarginStd;
    const twAbsolute = `absolute top-[${absTopStr}] left-[${absLeftStr}] w-[${wStr}] h-[${hStr}]`;
    const minW = Math.max(1, Math.round(w * 0.75));
    const maxW = w;
    const slopeW = ((maxW - minW) / (1440 - 375)) * 100;
    const interceptW = (minW - (slopeW / 100) * 375) / rootFs;
    const fluidWidth = `clamp(${(minW / rootFs).toFixed(2)}rem, ${interceptW.toFixed(2)}rem + ${slopeW.toFixed(2)}vw, ${(maxW / rootFs).toFixed(2)}rem)`;
    const minMt = Math.max(0, Math.round(topContent * 0.75));
    const maxMt = topContent;
    const slopeMt = ((maxMt - minMt) / (1440 - 375)) * 100;
    const interceptMt = (minMt - (slopeMt / 100) * 375) / rootFs;
    const fluidMt = `clamp(${(minMt / rootFs).toFixed(2)}rem, ${interceptMt.toFixed(2)}rem + ${slopeMt.toFixed(2)}vw, ${(maxMt / rootFs).toFixed(2)}rem)`;
    const cssFluid = `width: ${fluidWidth};\nmargin-block-start: ${fluidMt};`;
    const cssLogical = `inline-size: ${wStr};\nblock-size: ${hStr};\nmargin-block-start: ${topStr};\nmargin-inline-start: ${leftStr};`;
    const anchorTargetTag = nearby?.top?.tagName ? nearby.top.tagName.toLowerCase() : (parentTag || 'container');
    const cssAnchor = `/* CSS Anchor Positioning Module Level 1 */\n/* 1. 基準アンカー要素 (&lt;${anchorTargetTag}&gt;) に指定 */\n.anchor-target {\n  anchor-name: --${anchorTargetTag}-anchor;\n}\n\n/* 2. 対象要素 (相対配置) */\n.element {\n  position: absolute;\n  position-anchor: --${anchorTargetTag}-anchor;\n  top: anchor(bottom);\n  left: anchor(start);\n  margin-top: ${topStr};\n  margin-left: ${leftStr};\n  width: ${wStr};\n  height: ${hStr};\n}`;
    const cssFlow = `margin-top: ${topStr};\nmargin-left: ${leftStr};\nwidth: ${wStr};\nheight: ${hStr};`;
    const cssAbs = `position: absolute;\ntop: ${absTopStr};\nleft: ${absLeftStr};\nwidth: ${wStr};\nheight: ${hStr};`;
    const cssModule = `.element {\n  margin-top: ${topStr};\n  margin-left: ${leftStr};\n  width: ${wStr};\n  height: ${hStr};\n}`;
    const figmaJson = JSON.stringify({
      width: w,
      height: h,
      marginTop: topContent,
      marginLeft: leftContent,
      top: absTop,
      left: absLeft,
      right: absRight,
      bottom: absBottom,
      gapLeft: nearby?.left?.distance,
      gapRight: nearby?.right?.distance
    }, null, 2);
    panelContent.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center; background:#09090b; padding:4px 8px; border-radius:8px; border:1px solid #27272a; margin-bottom:10px;">
        <div style="display:flex; align-items:center; gap:4px;">
          <span style="font-size:10px; color:#a1a1aa;">${t('unit')}:</span>
          <div class="unit-switch">
            <button class="pill-btn ${activeUnit === 'px' ? 'active' : ''}" id="u-px">px</button>
            <button class="pill-btn ${activeUnit === 'rem' ? 'active' : ''}" id="u-rem">rem</button>
            <button class="pill-btn ${activeUnit === '%' ? 'active' : ''}" id="u-pct">%</button>
          </div>
        </div>
        <div style="display:flex; align-items:center; gap:4px;">
          <span style="font-size:10px; color:#a1a1aa;">${t('snap')}:</span>
          <div class="unit-switch">
            <button class="pill-btn ${snapGrid === 'none' ? 'active' : ''}" id="s-none">${t('snapNone')}</button>
            <button class="pill-btn ${snapGrid === '4px' ? 'active' : ''}" id="s-4">4px</button>
            <button class="pill-btn ${snapGrid === '8px' ? 'active' : ''}" id="s-8">8px</button>
          </div>
        </div>
      </div>
      ${nearby && (nearby.left || nearby.right) ? `
        <div style="background:#09090b; border:1px solid #f59e0b; border-radius:8px; padding:6px 8px; margin-bottom:8px; box-sizing:border-box;">
          <div style="font-size:10px; font-weight:700; color:#fbbf24; margin-bottom:4px;">${t('gapReverseTitle')}</div>
          <div style="display:flex; flex-direction:column; gap:4px; font-size:11px; font-family:monospace;">
            <div style="background:#18181b; padding:4px 6px; border-radius:4px; border:1px solid #27272a; word-break:break-all;">
              <span style="color:#f59e0b; font-weight:700;">${t('leftElement')}:</span> ${nearby.left ? `${nearby.left.distance}px (${leftTagStr})` : t('parentInner')}
            </div>
            <div style="background:#18181b; padding:4px 6px; border-radius:4px; border:1px solid #27272a; word-break:break-all;">
              <span style="color:#10b981; font-weight:700;">${t('rightElement')}:</span> ${nearby.right ? `${nearby.right.distance}px (${rightTagStr})` : t('parentInner')}
            </div>
          </div>
        </div>
      ` : ''}
      <div class="grid-4">
        <div class="metric-card">
          <div class="metric-title">${t('topMetric')}</div>
          <div class="metric-val">${topDist}px</div>
        </div>
        <div class="metric-card">
          <div class="metric-title">${t('leftMetric')}</div>
          <div class="metric-val">${leftDist}px</div>
        </div>
        <div class="metric-card">
          <div class="metric-title">${t('rightMetric')}</div>
          <div class="metric-val">${rightDist}px</div>
        </div>
        <div class="metric-card">
          <div class="metric-title">${t('bottomMetric')}</div>
          <div class="metric-val">${bottomDist}px</div>
        </div>
      </div>
      <div style="font-size:10px; color:#a1a1aa; margin-bottom:6px; background:#09090b; padding:4px 6px; border-radius:6px; border:1px solid #27272a; word-break:break-all;">
        Containing Block: <span style="color:#60a5fa; font-family:monospace; font-weight:bold;">${cbTagStr}</span>
        <div style="color:#9ca3af; font-size:9px; margin-top:2px;">${t('cbReasonLabel')}: ${cbReason}</div>
      </div>
      <div class="tab-switch" style="margin-bottom:8px; overflow-x:auto;">
        <button class="pill-btn ${activeTabFormat === 'tailwind' ? 'active' : ''}" id="tab-tw">Tailwind</button>
        <button class="pill-btn ${activeTabFormat === 'fluid' ? 'active' : ''}" id="tab-fluid">Fluid</button>
        <button class="pill-btn ${activeTabFormat === 'logical' ? 'active' : ''}" id="tab-log">Logical</button>
        <button class="pill-btn ${activeTabFormat === 'anchor' ? 'active' : ''}" id="tab-anc">Anchor</button>
        <button class="pill-btn ${activeTabFormat === 'css' ? 'active' : ''}" id="tab-css">CSS</button>
        <button class="pill-btn ${activeTabFormat === 'module' ? 'active' : ''}" id="tab-mod">Module</button>
        <button class="pill-btn ${activeTabFormat === 'figma' ? 'active' : ''}" id="tab-fig">Figma</button>
      </div>
      ${activeTabFormat === 'tailwind' ? `
        <div style="margin-bottom:6px;">
          <div style="font-size:10px; color:#a1a1aa; margin-bottom:2px; font-weight:600;">${t('stdScaleTitle')}</div>
          <div class="code-box">
            <span style="color:#34d399;">${twMarginStd}</span>
            <button class="copy-btn" id="btn-copy-tw1">${t('btnCopy')}</button>
          </div>
        </div>
        <div style="margin-bottom:6px;">
          <div style="font-size:10px; color:#a1a1aa; margin-bottom:2px; font-weight:600;">${t('arbitraryTitle')}</div>
          <div class="code-box">
            <span style="color:#a7f3d0;">${twMarginArb}</span>
            <button class="copy-btn" id="btn-copy-tw-arb">${t('btnCopy')}</button>
          </div>
        </div>
        <div style="margin-bottom:6px;">
          <div style="font-size:10px; color:#a1a1aa; margin-bottom:2px; font-weight:600;">${t('absoluteTitle')}</div>
          <div class="code-box">
            <span>${twAbsolute}</span>
            <button class="copy-btn" id="btn-copy-tw2">${t('btnCopy')}</button>
          </div>
        </div>
      ` : ''}
      ${activeTabFormat === 'fluid' ? `
        <div class="code-box" style="white-space:pre-wrap; display:block;">
          <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
            <span style="color:#a1a1aa;">${t('fluidTitle')}</span>
            <button class="copy-btn" id="btn-copy-fluid">${t('btnCopy')}</button>
          </div>
          <div style="color:#67e8f9;">${cssFluid}</div>
        </div>
      ` : ''}
      ${activeTabFormat === 'logical' ? `
        <div class="code-box" style="white-space:pre-wrap; display:block;">
          <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
            <span style="color:#a1a1aa;">CSS Logical Properties</span>
            <button class="copy-btn" id="btn-copy-log">${t('btnCopy')}</button>
          </div>
          <div style="color:#a5b4fc;">${cssLogical}</div>
        </div>
      ` : ''}
      ${activeTabFormat === 'anchor' ? `
        <div class="code-box" style="white-space:pre-wrap; display:block;">
          <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
            <span style="color:#a1a1aa;">CSS Anchor Positioning</span>
            <button class="copy-btn" id="btn-copy-anc">${t('btnCopy')}</button>
          </div>
          <div style="color:#d8b4fe;">${cssAnchor}</div>
        </div>
      ` : ''}
      ${activeTabFormat === 'css' ? `
        <div class="code-box" style="white-space:pre-wrap; display:block;">
          <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
            <span style="color:#a1a1aa;">${t('stdCssTitle')}</span>
            <button class="copy-btn" id="btn-copy-css">${t('btnCopy')}</button>
          </div>
          <div>${cssAbs}</div>
        </div>
      ` : ''}
      ${activeTabFormat === 'module' ? `
        <div class="code-box" style="white-space:pre-wrap; display:block;">
          <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
            <span style="color:#a1a1aa;">.module.css</span>
            <button class="copy-btn" id="btn-copy-mod">${t('btnCopy')}</button>
          </div>
          <div>${cssModule}</div>
        </div>
      ` : ''}
      ${activeTabFormat === 'figma' ? `
        <div class="code-box" style="white-space:pre-wrap; display:block;">
          <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
            <span style="color:#a1a1aa;">Figma Auto Layout (JSON)</span>
            <button class="copy-btn" id="btn-copy-fig">${t('btnCopy')}</button>
          </div>
          <div>${figmaJson}</div>
        </div>
      ` : ''}
      <!-- 位置・サイズ微調整カード -->
      <div style="background:#09090b; border:1px solid #27272a; border-radius:10px; padding:8px 10px; margin-top:8px;">
        <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:6px;">
          <span style="font-size:11px; font-weight:700; color:#e4e4e7; display:flex; align-items:center; gap:4px;">
            <span style="color:#a1a1aa;">✥</span> ${t('nudgeTitle')}
          </span>
          ${isNudgeDetached ? `
            <button class="pill-btn" id="btn-dock-inline" style="font-size:10px; background:#18181b; color:#38bdf8; border:1px solid #0284c7; padding:2px 6px; cursor:pointer;">${t('btnDock')}</button>
          ` : `
            <button class="pill-btn" id="btn-detach-nudge" style="font-size:10px; background:#18181b; color:#fbbf24; border:1px solid #d97706; padding:2px 6px; cursor:pointer;">${t('btnDetach')}</button>
          `}
        </div>
        ${isNudgeDetached ? `
          <div style="font-size:11px; color:#a1a1aa; background:#18181b; padding:8px; border-radius:6px; border:1px dashed #3f3f46; text-align:center;">
            ${t('detachedNotice')}<br>
            <span style="font-size:10px; color:#71717a;">${t('detachedSubNotice')}</span>
          </div>
        ` : `
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:6px;">
            <div style="background:#18181b; border:1px solid #27272a; border-radius:8px; padding:6px; display:flex; flex-direction:column; align-items:center; gap:4px;">
              <span style="font-size:10px; color:#a1a1aa; font-weight:600;">${t('nudgeMove')}</span>
              <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:3px; width:100%; max-width:96px;">
                <div></div>
                <button class="nudge-btn" id="btn-nudge-up-inline">▲</button>
                <div></div>
                <button class="nudge-btn" id="btn-nudge-left-inline">◀</button>
                <button class="nudge-btn" id="btn-nudge-down-inline">▼</button>
                <button class="nudge-btn" id="btn-nudge-right-inline">▶</button>
              </div>
            </div>
            <div style="background:#18181b; border:1px solid #27272a; border-radius:8px; padding:6px; display:flex; flex-direction:column; align-items:center; gap:4px;">
              <span style="font-size:10px; color:#a1a1aa; font-weight:600;">${t('nudgeResize')}</span>
              <div style="display:grid; grid-template-columns:1fr 1fr; gap:3px; width:100%; font-size:10px;">
                <button class="nudge-btn" id="btn-nudge-wplus-inline">W +1</button>
                <button class="nudge-btn" id="btn-nudge-wminus-inline">W -1</button>
                <button class="nudge-btn" id="btn-nudge-hplus-inline">H +1</button>
                <button class="nudge-btn" id="btn-nudge-hminus-inline">H -1</button>
              </div>
            </div>
          </div>
        `}
      </div>
    `;
    detachedNudgeBody.innerHTML = `
      <div style="display:grid; grid-template-columns:1fr 1fr; gap:6px;">
        <div style="background:#18181b; border:1px solid #27272a; border-radius:8px; padding:6px; display:flex; flex-direction:column; align-items:center; gap:4px;">
          <span style="font-size:10px; color:#a1a1aa; font-weight:600;">${t('nudgeMove')}</span>
          <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:3px; width:100%; max-width:96px;">
            <div></div>
            <button class="nudge-btn" id="btn-nudge-up-detached">▲</button>
            <div></div>
            <button class="nudge-btn" id="btn-nudge-left-detached">◀</button>
            <button class="nudge-btn" id="btn-nudge-down-detached">▼</button>
            <button class="nudge-btn" id="btn-nudge-right-detached">▶</button>
          </div>
        </div>
        <div style="background:#18181b; border:1px solid #27272a; border-radius:8px; padding:6px; display:flex; flex-direction:column; align-items:center; gap:4px;">
          <span style="font-size:10px; color:#a1a1aa; font-weight:600;">${t('nudgeResize')}</span>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:3px; width:100%; font-size:10px;">
            <button class="nudge-btn" id="btn-nudge-wplus-detached">W +1</button>
            <button class="nudge-btn" id="btn-nudge-wminus-detached">W -1</button>
            <button class="nudge-btn" id="btn-nudge-hplus-detached">H +1</button>
            <button class="nudge-btn" id="btn-nudge-hminus-detached">H -1</button>
          </div>
        </div>
      </div>
      <div style="font-size:10px; color:#71717a; text-align:center; margin-top:6px;">
        ${t('nudgeShortcutHelp')}
      </div>
    `;
    shadow.getElementById('btn-detach-nudge')?.addEventListener('click', () => {
      isNudgeDetached = true;
      detachedWindow.style.display = 'block';
      renderAll(currentBox);
    });
    shadow.getElementById('btn-dock-inline')?.addEventListener('click', () => {
      isNudgeDetached = false;
      detachedWindow.style.display = 'none';
      renderAll(currentBox);
    });
    const bindNudgeBtn = (id, dx, dy, dw, dh) => {
      shadow.getElementById(id)?.addEventListener('click', (e) => {
        e.stopPropagation();
        nudgeBox(dx, dy, dw, dh);
      });
    };
    bindNudgeBtn('btn-nudge-up-inline', 0, -1, 0, 0);
    bindNudgeBtn('btn-nudge-down-inline', 0, 1, 0, 0);
    bindNudgeBtn('btn-nudge-left-inline', -1, 0, 0, 0);
    bindNudgeBtn('btn-nudge-right-inline', 1, 0, 0, 0);
    bindNudgeBtn('btn-nudge-wplus-inline', 0, 0, 1, 0);
    bindNudgeBtn('btn-nudge-wminus-inline', 0, 0, -1, 0);
    bindNudgeBtn('btn-nudge-hplus-inline', 0, 0, 0, 1);
    bindNudgeBtn('btn-nudge-hminus-inline', 0, 0, 0, -1);
    bindNudgeBtn('btn-nudge-up-detached', 0, -1, 0, 0);
    bindNudgeBtn('btn-nudge-down-detached', 0, 1, 0, 0);
    bindNudgeBtn('btn-nudge-left-detached', -1, 0, 0, 0);
    bindNudgeBtn('btn-nudge-right-detached', 1, 0, 0, 0);
    bindNudgeBtn('btn-nudge-wplus-detached', 0, 0, 1, 0);
    bindNudgeBtn('btn-nudge-wminus-detached', 0, 0, -1, 0);
    bindNudgeBtn('btn-nudge-hplus-detached', 0, 0, 0, 1);
    bindNudgeBtn('btn-nudge-hminus-detached', 0, 0, 0, -1);
    shadow.getElementById('u-px')?.addEventListener('click', () => { activeUnit = 'px'; renderAll(currentBox); });
    shadow.getElementById('u-rem')?.addEventListener('click', () => { activeUnit = 'rem'; renderAll(currentBox); });
    shadow.getElementById('u-pct')?.addEventListener('click', () => { activeUnit = '%'; renderAll(currentBox); });
    shadow.getElementById('s-none')?.addEventListener('click', () => { snapGrid = 'none'; renderAll(currentBox); });
    shadow.getElementById('s-4')?.addEventListener('click', () => { snapGrid = '4px'; renderAll(currentBox); });
    shadow.getElementById('s-8')?.addEventListener('click', () => { snapGrid = '8px'; renderAll(currentBox); });
    shadow.getElementById('tab-tw')?.addEventListener('click', () => { activeTabFormat = 'tailwind'; renderAll(currentBox); });
    shadow.getElementById('tab-fluid')?.addEventListener('click', () => { activeTabFormat = 'fluid'; renderAll(currentBox); });
    shadow.getElementById('tab-log')?.addEventListener('click', () => { activeTabFormat = 'logical'; renderAll(currentBox); });
    shadow.getElementById('tab-anc')?.addEventListener('click', () => { activeTabFormat = 'anchor'; renderAll(currentBox); });
    shadow.getElementById('tab-css')?.addEventListener('click', () => { activeTabFormat = 'css'; renderAll(currentBox); });
    shadow.getElementById('tab-mod')?.addEventListener('click', () => { activeTabFormat = 'module'; renderAll(currentBox); });
    shadow.getElementById('tab-fig')?.addEventListener('click', () => { activeTabFormat = 'figma'; renderAll(currentBox); });
    const bindCopy = (id, text) => {
      const btn = shadow.getElementById(id);
      if (!btn) return;
      btn.addEventListener('click', () => {
        navigator.clipboard.writeText(text).then(() => {
          const original = btn.textContent;
          btn.textContent = t('copied');
          btn.style.background = '#059669';
          setTimeout(() => {
            btn.textContent = original;
            btn.style.background = '#27272a';
          }, 1500);
        });
      });
    };
    bindCopy('btn-copy-tw1', twMarginStd);
    bindCopy('btn-copy-tw-arb', twMarginArb);
    bindCopy('btn-copy-tw2', twAbsolute);
    bindCopy('btn-copy-fluid', cssFluid);
    bindCopy('btn-copy-log', cssLogical);
    bindCopy('btn-copy-anc', cssAnchor);
    bindCopy('btn-copy-css', cssAbs);
    bindCopy('btn-copy-mod', cssModule);
    bindCopy('btn-copy-fig', figmaJson);
  }
})();
