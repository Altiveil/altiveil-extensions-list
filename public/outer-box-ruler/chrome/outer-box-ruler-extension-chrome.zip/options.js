document.addEventListener('DOMContentLoaded', () => {
  chrome.storage.local.get({ defaultUnit: 'px', defaultSnap: 'none' }, (items) => {
    document.getElementById('defaultUnit').value = items.defaultUnit || 'px';
    document.getElementById('defaultSnap').value = items.defaultSnap || 'none';
  });
});
document.getElementById('saveBtn').addEventListener('click', () => {
  const defaultUnit = document.getElementById('defaultUnit').value;
  const defaultSnap = document.getElementById('defaultSnap').value;
  chrome.storage.local.set({ defaultUnit, defaultSnap }, () => {
    const status = document.getElementById('status');
    status.textContent = '設定を保存しました。';
    setTimeout(() => { status.textContent = ''; }, 2000);
  });
});
