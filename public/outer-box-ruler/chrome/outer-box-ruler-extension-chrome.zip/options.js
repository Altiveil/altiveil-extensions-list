const I18N = {
  ja: {
    pageTitle: '外枠px逆算定規 - 設定',
    headingTitle: '外枠px逆算定規 設定',
    lblLang: '表示言語',
    optLangAuto: 'ブラウザ言語に従う (Auto)',
    lblUnit: 'デフォルト計算単位',
    optUnitPx: 'px (ピクセル)',
    optUnitRem: 'rem (ルート基準 16px)',
    optUnitPct: '% (親要素パーセント比)',
    lblSnap: 'デフォルトグリッドスナップ',
    optSnapNone: 'なし (1px精密)',
    optSnap4: '4px グリッド',
    optSnap8: '8px グリッド',
    btnSave: '設定を保存',
    statusSaved: '設定を保存しました。'
  },
  en: {
    pageTitle: 'Outer Box Ruler - Settings',
    headingTitle: 'Outer Box Ruler Settings',
    lblLang: 'Language',
    optLangAuto: 'Follow Browser (Auto)',
    lblUnit: 'Default Unit',
    optUnitPx: 'px (Pixel)',
    optUnitRem: 'rem (Root 16px base)',
    optUnitPct: '% (Parent Ratio)',
    lblSnap: 'Default Grid Snap',
    optSnapNone: 'None (1px precision)',
    optSnap4: '4px Grid',
    optSnap8: '8px Grid',
    btnSave: 'Save Settings',
    statusSaved: 'Settings saved.'
  }
};

function resolveLang(langPref) {
  if (langPref === 'ja' || langPref === 'en') return langPref;
  const navLang = (navigator.language || '').toLowerCase();
  return navLang.startsWith('ja') ? 'ja' : 'en';
}

function applyLabels(lang) {
  const dict = I18N[lang] || I18N.en;
  document.getElementById('pageTitle').textContent = dict.pageTitle;
  document.getElementById('headingTitle').textContent = dict.headingTitle;
  document.getElementById('lblLang').textContent = dict.lblLang;
  document.querySelector('#langSelect option[value="auto"]').textContent = dict.optLangAuto;
  document.getElementById('lblUnit').textContent = dict.lblUnit;
  document.getElementById('optUnitPx').textContent = dict.optUnitPx;
  document.getElementById('optUnitRem').textContent = dict.optUnitRem;
  document.getElementById('optUnitPct').textContent = dict.optUnitPct;
  document.getElementById('lblSnap').textContent = dict.lblSnap;
  document.getElementById('optSnapNone').textContent = dict.optSnapNone;
  document.getElementById('optSnap4').textContent = dict.optSnap4;
  document.getElementById('optSnap8').textContent = dict.optSnap8;
  document.getElementById('saveBtn').textContent = dict.btnSave;
}

document.addEventListener('DOMContentLoaded', () => {
  chrome.storage.local.get({ defaultUnit: 'px', defaultSnap: 'none', lang: 'auto' }, (items) => {
    document.getElementById('defaultUnit').value = items.defaultUnit || 'px';
    document.getElementById('defaultSnap').value = items.defaultSnap || 'none';
    document.getElementById('langSelect').value = items.lang || 'auto';
    applyLabels(resolveLang(items.lang));
  });
});

document.getElementById('langSelect').addEventListener('change', (e) => {
  applyLabels(resolveLang(e.target.value));
});

document.getElementById('saveBtn').addEventListener('click', () => {
  const defaultUnit = document.getElementById('defaultUnit').value;
  const defaultSnap = document.getElementById('defaultSnap').value;
  const lang = document.getElementById('langSelect').value;
  chrome.storage.local.set({ defaultUnit, defaultSnap, lang }, () => {
    const currentLang = resolveLang(lang);
    const status = document.getElementById('status');
    status.textContent = I18N[currentLang].statusSaved;
    setTimeout(() => { status.textContent = ''; }, 2000);
  });
});
