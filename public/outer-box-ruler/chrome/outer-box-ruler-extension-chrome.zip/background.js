chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: 'toggle-outer-box-ruler',
      title: chrome.i18n.getMessage('ctxMenuTitle') || '外枠px逆算定規を起動 / 停止 (Alt+R)',
      contexts: ['all']
    });
  });
});
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === 'toggle-outer-box-ruler' && tab) {
    toggleRulerOnTab(tab);
  }
});
chrome.commands.onCommand.addListener(async (command) => {
  if (command === 'toggle-ruler') {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) {
      toggleRulerOnTab(tab);
    }
  }
});
async function toggleRulerOnTab(tab) {
  if (!tab || !tab.id) return;
  const tabId = tab.id;
  if (tab.url && (tab.url.startsWith('chrome://') || tab.url.startsWith('edge://') || tab.url.startsWith('about:') || tab.url.startsWith('chrome-extension://'))) {
    console.warn('Outer Box Ruler: Cannot run on browser internal system pages.');
    return;
  }
  try {
    const response = await chrome.tabs.sendMessage(tabId, { type: 'TOGGLE_RULER' });
    if (response && response.success) return;
  } catch (err) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: ['content.js']
      });
      await chrome.scripting.executeScript({
        target: { tabId: tabId },
        func: () => {
          if (typeof window.__OUTER_BOX_RULER_TOGGLE__ === 'function') {
            window.__OUTER_BOX_RULER_TOGGLE__();
          }
        }
      });
    } catch (injectErr) {
      console.error('Outer Box Ruler: Script injection error:', injectErr);
    }
  }
}
