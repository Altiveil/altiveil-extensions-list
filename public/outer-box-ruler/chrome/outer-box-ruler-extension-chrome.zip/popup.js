const I18N = {
  ja: {
    popupTitle: '外枠px逆算定規',
    btnText: '定規モードを起動',
    lblShortcutHeader: 'ショートカット:',
    pShortcutHelp: 'いつでも <span class="shortcut">Alt + R</span> (Mac: Option+R) または画面上の右クリックメニューから起動できます。',
    lblUsageHeader: '使い方:',
    pUsageHelp: '画面上をドラッグして枠描画するか要素をクリックすると、親要素との余白を自動逆算してTailwind/CSSを出力します。',
    alertInternal: 'ブラウザ内部ページでは拡張機能は起動できません。通常のWebページでお試しください。'
  },
  en: {
    popupTitle: 'Outer Box Ruler',
    btnText: 'Launch Ruler Mode',
    lblShortcutHeader: 'Shortcut:',
    pShortcutHelp: 'Press <span class="shortcut">Alt + R</span> (Mac: Option+R) anytime or right-click on any web page.',
    lblUsageHeader: 'How to Use:',
    pUsageHelp: 'Drag to draw a box or click an element to measure distance to parent/sibling and export Tailwind/CSS.',
    alertInternal: 'Cannot run on browser internal pages. Please try on a standard web page.'
  }
};

let currentLang = 'ja';

function resolveLang(langPref) {
  if (langPref === 'ja' || langPref === 'en') return langPref;
  const navLang = (navigator.language || '').toLowerCase();
  return navLang.startsWith('ja') ? 'ja' : 'en';
}

document.addEventListener('DOMContentLoaded', () => {
  chrome.storage.local.get({ lang: 'auto' }, (items) => {
    currentLang = resolveLang(items.lang);
    const dict = I18N[currentLang] || I18N.en;
    document.getElementById('popupTitle').textContent = dict.popupTitle;
    document.getElementById('btnText').textContent = dict.btnText;
    document.getElementById('lblShortcutHeader').textContent = dict.lblShortcutHeader;
    document.getElementById('pShortcutHelp').innerHTML = dict.pShortcutHelp;
    document.getElementById('lblUsageHeader').textContent = dict.lblUsageHeader;
    document.getElementById('pUsageHelp').textContent = dict.pUsageHelp;
  });
});

document.getElementById('toggleBtn').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) return;
  if (tab.url && (tab.url.startsWith('chrome://') || tab.url.startsWith('edge://') || tab.url.startsWith('about:') || tab.url.startsWith('chrome-extension://'))) {
    const dict = I18N[currentLang] || I18N.en;
    alert(dict.alertInternal);
    return;
  }
  try {
    await chrome.tabs.sendMessage(tab.id, { type: 'TOGGLE_RULER' });
  } catch (err) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content.js']
      });
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          if (typeof window.__OUTER_BOX_RULER_TOGGLE__ === 'function') {
            window.__OUTER_BOX_RULER_TOGGLE__();
          }
        }
      });
    } catch (e) {
      console.error('Cannot inject ruler script:', e);
    }
  }
  window.close();
});
