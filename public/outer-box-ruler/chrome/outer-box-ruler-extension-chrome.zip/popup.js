document.getElementById('toggleBtn').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) return;
  if (tab.url && (tab.url.startsWith('chrome://') || tab.url.startsWith('edge://') || tab.url.startsWith('about:') || tab.url.startsWith('chrome-extension://'))) {
    alert('ブラウザ内部ページでは拡張機能は起動できません。通常のWebページでお試しください。');
    return;
  }
  try {
    await chrome.tabs.sendMessage(tab.id, { type: 'TOGGLE_RULER' });
  } catch (err) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content.js']
      });
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          if (typeof window.__OUTER_BOX_RULER_TOGGLE__ === 'function') {
            window.__OUTER_BOX_RULER_TOGGLE__();
          }
        }
      });
    } catch (e) {
      console.error('Cannot inject ruler script:', e);
    }
  }
  window.close();
});
