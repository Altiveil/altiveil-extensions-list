# Chrome Web Store 掲載用メタデータ

## 拡張機能名
外枠px逆算定規 - Outer Box Ruler for Tailwind & CSS

## 短い説明 (132文字以内)
包含ブロック(Containing Block)と周辺要素までの余白を自動逆算！Tailwind CSSや標準CSSコードを瞬時に生成するエンジニア・デザイナー向け定規ツール。

## カテゴリ
デベロッパー ツール (Developer Tools)

## 詳細説明
Webフロントエンド開発、UI/UXデザイン、デザインカンプのピクセルパーフェクトな再現に最適なプロフェッショナル定規拡張機能です。

単なる画面座標の測定にとどまらず、CSS仕様（W3C Display/Positioning Modules）に基づいた高精度なDOM解析ロジックを搭載しています。

### 圧倒的な差別化機能・特長

1. **高精度 Containing Block (包含ブロック) 自動検出エンジン**:
   - `position: absolute` や `fixed` 配置時、単純な親要素ではなく、`position: relative/absolute/fixed` や `transform`, `filter`, `perspective`, `contain`, `container-type` を保持する「真の基準要素（Containing Block）」を自動特定。
   - **「なぜその位置・距離になるのか」** をCSS仕様レベルで解明し、確実なコードを逆算出力します。

2. **階層別デュアル距離ガイド (二重測定モード)**:
   - 直近の親コンテナまでの距離（赤線）と、隣接する周囲の兄弟・近接要素までの距離（紫色・橙色・緑線）を2段重ねで同時にリアルタイム描画。
   - 要素間の空き（gap/margin）とコンテナ外枠距離を一目で同時に把握できます。

3. **あらゆるモダンCSS構文へのワンクリック変換**:
   - **Tailwind CSS**: Arbitrary形式 (`mt-[24px]`) および Standard Scale形式 (`mt-6`)
   - **CSS Fluid clamp()**: 画面幅に応じた動的応答レスポンシブ関数 (`clamp(1rem, 2.5vw, 2rem)`)
   - **CSS Logical Properties**: グローバル多言語対応論理プロパティ (`margin-block-start`, `inline-size`)
   - **CSS Anchor Positioning**: 最新CSSアンカー配置 (`position-anchor`, `top: anchor(bottom)`)
   - **Figma Auto Layout**: デザインシステム連携トークンデータ (JSON)

4. **Shadow DOM による完全CSS隔離**:
   - 測定用UIはすべて Shadow DOM 内に描画されるため、測定対象WebサイトのCSSスタイル崩れを起こさず、干渉ゼロで安全・軽量に動作します。

5. **矢印キーによる 1px / 10px 精密調整 & 切り離し機能**:
   - 矢印キー（1px単位）および Shift+矢印キー（10px単位）で描画枠をキーボード微調整。切り離しミニウィンドウでメイン画面を遮らず作業可能です。

---

### ショートカットキー
- **起動 / 終了トグル**: `Alt + R` (Mac: `Option + R`)
- **コンテキストメニュー**: 画面上を右クリック ➔ 「外枠px逆算定規を起動」
- **終了**: `Esc` キー
